<html>
    <head>
        <title>Google Maps Multiple Markers</title>
        <script type="text/javascript" src="src/markerclusterer.js"></script>
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCXjNiBAPE85qtu9R4E1avqGT3YcvmYtmMvin&callback=initMap&sensor=false"></script>
        <script type="text/javascript" src="location_list.js"></script>
    </head>
    <body>
        <div id="map" style="height: 400px; width: 500px;"></div>
        <script type="text/javascript">
            function initMap() {
                var map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 10,
                    center: new google.maps.LatLng(-33.92, 151.25),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var bounds = new google.maps.LatLngBounds();

                var infowindow = new google.maps.InfoWindow();

                var marker, i;

                var markers = [];

                for (i = 0; i < locations.length; i++) {
                    marker = new google.maps.Marker({
                        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                        map: map,
                        title: locations[i][0],
                    });

                    markers.push(marker);

                    //extend the bounds to include each marker's position
                    bounds.extend(marker.position);

                    google.maps.event.addListener(marker, 'click', (function (marker, i) {
                        return function () {
                            infowindow.setContent(locations[i][3]);
                            infowindow.open(map, marker);
                        }
                    })(marker, i));
                }

                var options = {
                    imagePath: 'images/m'
                };

                // Uncomment below line for clustering
                // var markerCluster = new MarkerClusterer(map, markers, options);

                //now fit the map to the newly inclusive bounds
                map.fitBounds(bounds);

                //(optional) restore the zoom level after the map is done scaling
                var listener = google.maps.event.addListener(map, "idle", function () {
                    map.setZoom(3);
                    google.maps.event.removeListener(listener);
                });
            }
        </script>
    </body>
</html>