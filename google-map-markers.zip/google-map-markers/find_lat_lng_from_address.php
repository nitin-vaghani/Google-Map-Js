<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    define('DB_SERVER', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_DATABASE', 'test');


    $link = mysqli_connect(DB_SERVER, DB_USER, DB_PASS) or die("Could not connect with server.");
    if (!$link) {
        die('Could not connect: ' . mysqli_error());
    } else {
        mysqli_select_db($link, DB_DATABASE);
    }

    // function to geocode address, it will return false if unable to geocode address
    function geocode($address) {

        // url encode the address
        $address = urlencode($address);

        // google map geocode api url
        $url = "https://maps.googleapis.com/maps/api/geocode/json?address={$address}&key=AIzaSyAYgCIHQTLs-YYmrNMB8Kw-kxvYCz1c_lAvin";
//        echo $url;die;
        // get the json response
        $resp_json = file_get_contents($url);

        // decode the json
        $resp = json_decode($resp_json, true);

//        dd($resp);
        // response status will be 'OK', if able to geocode given address 
        if ($resp['status'] == 'OK') {

            // get the important data
            $lat = isset($resp['results'][0]['geometry']['location']['lat']) ? $resp['results'][0]['geometry']['location']['lat'] : "";
            $lng = isset($resp['results'][0]['geometry']['location']['lng']) ? $resp['results'][0]['geometry']['location']['lng'] : "";
            $formatted_address = isset($resp['results'][0]['formatted_address']) ? $resp['results'][0]['formatted_address'] : "";

            // verify if data is complete
            if ($lat && $lng && $formatted_address) {

                // put the data in the array
                $data_arr = array(
//                    id="1", name="Billy Kwong" address="1/28 Macleay Street, Elizabeth Bay, NSW" lat="-33.869843" lng="-151.225769" type="pickup_point"
                    'lat' => $lat,
                    'lng' => $lng,
                    'address' => $formatted_address,
                    'postal_code' => "",
                );

                return $data_arr;
            } else {
                return false;
            }
        } else {
//            echo "<strong>ERROR: {$resp['status']}</strong>";
            return false;
        }
    }

    function selectArray($query) {
        $array = array();
        $result = mysqlQuery($query);
        while ($object = mysqli_fetch_assoc($result)) {
            $array[] = $object;
        }
        mysqli_free_result($result);
        return $array;
    }

    function selectObject($query) {
        $result = mysqlQuery($query);

        $object = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        return $object;
    }

    function insertQuery($query) {
        global $link;
        $result = mysqlQuery($query);
        if (mysqli_insert_id($link))
            $result = mysqli_insert_id($link);
        return $result;
    }

    function mysqlQuery($query) {
        global $link;
        $result = mysqli_query($link, $query);
        if (!$result) {
            return mysqli_error($link);
        }
        return $result;
    }

    function insertArray($usrData, $table) {
        $q = "INSERT INTO `" . $table . "` ";
        $v = '';
        $n = '';

        foreach ($usrData as $key => $val) {
            $n .= "`$key`, ";
            if (strtolower($val) == 'null')
                $v .= "NULL, ";
            elseif (strtolower($val) == 'now()')
                $v .= "NOW(), ";
            else
                $v .= "'" . mysql_real_escape_string($val) . "', ";
        }

        $q .= "(" . rtrim($n, ', ') . ") VALUES (" . rtrim($v, ', ') . ");";
        $id = insertQuery($q);
        return $id;
    }

    /**
     * 
     * @param type $data = array
     * @param type $flag = 0 print, 1=exit
     */
    function dd($data, $flag = 1) {
        echo '<pre>';
        if ($flag) {
            print_r($data);
            exit;
        } else {
            print_r($data);
        }
        echo '</pre>';
    }

    $type = isset($_REQUEST['type']) ? trim($_REQUEST['type']) : '';
//    echo $type;die;
    $resultArr = array();
    switch ($type) {
        case 'generateJson':
//            http://localhost/test/google-map/find_lat_lng_from_address.php?type=generateJson
            $sql = "SELECT dispatch_origin,lat,lng,content FROM location_list WHERE (lat IS NOT NULL OR lat !='') AND (lng IS NOT NULL OR lng !='') LIMIT 1000";
            $resultList = selectArray($sql);

//          dd($resultList, 1);

            if (!empty($resultList) && count($resultList) > 0) {
                foreach ($resultList as $value) {
                    $resultArr[] = [$value['dispatch_origin'], $value['lat'], $value['lng'], trim(preg_replace('/\s\s+/', ' ', $value['content']))];
                }
            }

            header("content-type:application/json");
            echo json_encode($resultArr, JSON_UNESCAPED_SLASHES);
            break;
        case 'findLatLng':
            //http://localhost/test/google-map/find_lat_lng_from_address.php?type=findLatLng
//            $sql = "SELECT * FROM location_list LIMIT 1000";
            $sql = "SELECT * FROM location_list WHERE dispatch_origin !='' AND (lat IS NULL OR lat='') AND (lng IS NULL OR lng='') LIMIT 10";
            $resultArr = selectArray($sql);
//    dd($resultArr, 1);

            if (!empty($resultArr) && count($resultArr) > 0) {

                foreach ($resultArr as $value) {
                    $result = geocode($value['dispatch_origin']);
//                    dd($result, 1);
                    if (!empty($result) && !empty($result['lat']) && !empty($result['lng'])) {

                        $info = '<div class="info_content"><h3>' . $value["dispatch_origin"] . '</h3><p> Vahicle List : ' . $value["vehicles_list"] . '</p>';
                        if (!empty($value['pickup_date'])) {
                            $info .= '<p> Pickup Date : ' . $value["pickup_date"] . '</p>';
                        }
                        $info .= '</div>';

                        $query = "UPDATE 
                                location_list 
                          SET 
                                lat='" . $result['lat'] . "',lng='" . $result['lng'] . "',content='" . mysqli_real_escape_string($link, $info) . "'
                          WHERE 
                                id=" . $value['id'];
//                        echo $query;die;
                        $response = mysqlQuery($query);

//                        dd($response);
                    }
                }
            }
            echo 'Done';
            die;
            break;
        default :
            break;
    }
} catch (Exception $e) {
    echo '<prE>';
    print_r($e->getMessage());
    exit;
}
