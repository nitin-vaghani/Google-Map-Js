<html>
    <head>
        <title>Google Maps Multiple Markers</title>
        <!--<script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>-->
        <script type="text/javascript" src="src/markerclusterer.js"></script>

        <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCXjNiBAPE85qtu9R4E1avqGT3YcvmYtmMvin&callback=initMap&sensor=false">
        </script>
        <script type="text/javascript" src="location_list.js"></script>
    </head>
    <body>
        <div id="map" style="height: 400px; width: 500px;">
        </div>
        <script type="text/javascript">
                    function initMap() {
//                var locations = [
//                    ['India', 23.5654564, 72.1234564, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>'],
//                    ['Bondi Beach', -33.890542, 151.274856, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>'],
//                    ['Coogee Beach', -33.923036, 151.259052, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>'],
//                    ['Cronulla Beach', -34.028249, 151.157507, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>'],
//                    ['Manly Beach', -33.80010128657071, 151.28747820854187, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>'],
//                    ['Maroubra Beach', -33.950198, 151.259302, '<div class="info_content"><h3>London Eye</h3><p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p></div>']
//                ];

//                var locations = [
//                    [
//                        "Olufunsho Ashowo, GA (30106)",
//                        "33.8417064",
//                        "-84.6322156",
//                        "<div class=\"info_content\"><h3>Olufunsho Ashowo, GA (30106)</h3><p> Vahicle List : Toyota Sienna 2003</p></div>"
//                    ],
//                    [
//                        "Copart-Louisville, KY (40272)",
//                        "38.1097564",
//                        "-85.8203662",
//                        "<div class=\"info_content\"><h3>Copart-Louisville, KY (40272)</h3><p> Vahicle List : Toyota Highlander 2006, Toyota Corolla 2006</p></div>"
//                    ],
//                    [
//                        "Copart-Colton, CA (92324)",
//                        "34.0495279",
//                        "-117.33171",
//                        "<div class=\"info_content\"><h3>Copart-Colton, CA (92324)</h3><p> Vahicle List : Toyota Corolla 2005</p><p> Pickup Date : October 18, 2019</p></div>"
//                    ]
//                ];

                        var map = new google.maps.Map(document.getElementById('map'), {
                            zoom: 10,
                            center: new google.maps.LatLng(-33.92, 151.25),
                            mapTypeId: google.maps.MapTypeId.ROADMAP
                        });

                        var bounds = new google.maps.LatLngBounds();

                        var infowindow = new google.maps.InfoWindow();

                        var marker, i;

                        var markers = [];

                        for (i = 0; i < locations.length; i++) {
                            marker = new google.maps.Marker({
                                position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                                map: map,
                                title: locations[i][0],
                            });

                            markers.push(marker);

                            //extend the bounds to include each marker's position
                            bounds.extend(marker.position);

                            google.maps.event.addListener(marker, 'click', (function (marker, i) {
                                return function () {
                                    infowindow.setContent(locations[i][3]);
                                    infowindow.open(map, marker);
                                }
                            })(marker, i));
                        }

                        var options = {
                            imagePath: 'images/m'
                        };
                        // Ubcomment below line for clustering
//                        var markerCluster = new MarkerClusterer(map, markers, options);

                        //now fit the map to the newly inclusive bounds
                        map.fitBounds(bounds);

                        //(optional) restore the zoom level after the map is done scaling
                        var listener = google.maps.event.addListener(map, "idle", function () {
                            map.setZoom(3);
                            google.maps.event.removeListener(listener);
                        });
                    }
        </script>

    </body>
</html>