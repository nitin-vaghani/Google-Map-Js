var locations =
        [

            [
                "Olufunsho Ashowo, GA (30106)",
                "33.8417064",
                "-84.6322156",
                "<div class=\"info_content\"><h3>Olufunsho Ashowo, GA (30106)</h3><p> Vehicle List : Toyota Sienna 2003</p></div>"
            ],
            [
                "Copart-Louisville, KY (40272)",
                "38.1097564",
                "-85.8203662",
                "<div class=\"info_content\"><h3>Copart-Louisville, KY (40272)</h3><p> Vehicle List : Toyota Highlander 2006, Toyota Corolla 2006</p></div>"
            ],
            [
                "Copart-Colton, CA (92324)",
                "34.0495279",
                "-117.33171",
                "<div class=\"info_content\"><h3>Copart-Colton, CA (92324)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : October 18, 2019</p></div>"
            ],
            [
                "Ernest Enyi, NY (11692)",
                "40.592658",
                "-73.7977928",
                "<div class=\"info_content\"><h3>Ernest Enyi, NY (11692)</h3><p> Vehicle List : Chevy Silverado 2006</p></div>"
            ],
            [
                "IAAI- Jacksonville, FL (32219)",
                "30.4963744",
                "-81.7892703",
                "<div class=\"info_content\"><h3>IAAI- Jacksonville, FL (32219)</h3><p> Vehicle List : Nissan Altima 2012, Toyota Camry 2009</p></div>"
            ],
            [
                "Copart-Byron, GA (31008)",
                "32.6832367",
                "-83.7063443",
                "<div class=\"info_content\"><h3>Copart-Byron, GA (31008)</h3><p> Vehicle List : Toyota Camry 2004</p><p> Pickup Date : October 18, 2019</p></div>"
            ],
            [
                "IAAI- Fletcher, NC (28732)",
                "35.4143834",
                "-82.5068501",
                "<div class=\"info_content\"><h3>IAAI- Fletcher, NC (28732)</h3><p> Vehicle List : Toyota Camry 2004</p></div>"
            ],
            [
                "IAAI-Wilmer, TX (75172)",
                "32.5783512",
                "-96.6696343",
                "<div class=\"info_content\"><h3>IAAI-Wilmer, TX (75172)</h3><p> Vehicle List : Toyota Rav4 2009</p><p> Pickup Date : October 18, 2019</p></div>"
            ],
            [
                "Copart- Hartford, CT (06051)",
                "41.6504863",
                "-72.7505585",
                "<div class=\"info_content\"><h3>Copart- Hartford, CT (06051)</h3><p> Vehicle List : Lexus GX 470 2004</p><p> Pickup Date : October 21, 2019</p></div>"
            ],
            [
                "IAAI- Pittson, PA (18640)",
                "41.3082996",
                "-75.8032845",
                "<div class=\"info_content\"><h3>IAAI- Pittson, PA (18640)</h3><p> Vehicle List : Toyota Sienna 2008</p></div>"
            ],
            [
                "Copart- Columbus Station, OH (44028)",
                "41.3128286",
                "-81.9838598",
                "<div class=\"info_content\"><h3>Copart- Columbus Station, OH (44028)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : October 17, 2019</p></div>"
            ],
            [
                "Mr. Joe, NY (11433)",
                "40.6970073",
                "-73.7912899",
                "<div class=\"info_content\"><h3>Mr. Joe, NY (11433)</h3><p> Vehicle List : Hyundai Sonata 2011</p><p> Pickup Date : October 17, 2019</p></div>"
            ],
            [
                "IAAI-Lorain, OH (44053)",
                "41.4116052",
                "-82.2795031",
                "<div class=\"info_content\"><h3>IAAI-Lorain, OH (44053)</h3><p> Vehicle List : Toyota Sienna 2006</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "IAAI- Aurora, IL (60505)",
                "41.7896626",
                "-88.3070542",
                "<div class=\"info_content\"><h3>IAAI- Aurora, IL (60505)</h3><p> Vehicle List : Lexus Rx350 2013</p><p> Pickup Date : October 16, 2019</p></div>"
            ],
            [
                "C/o Joseph Okafor, TX (77042)",
                "29.7246822",
                "-95.5564777",
                "<div class=\"info_content\"><h3>C/o Joseph Okafor, TX (77042)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : October 16, 2019</p></div>"
            ],
            [
                "Emmanuel Nliam, NY (11554)",
                "40.7179622",
                "-73.5535234",
                "<div class=\"info_content\"><h3>Emmanuel Nliam, NY (11554)</h3><p> Vehicle List : Toyota Camry 2014</p><p> Pickup Date : October 16, 2019</p></div>"
            ],
            [
                "Copart- Colorado Springs, CO (80907)",
                "38.886995",
                "-104.815413",
                "<div class=\"info_content\"><h3>Copart- Colorado Springs, CO (80907)</h3><p> Vehicle List : Toyota Highlander 2008</p><p> Pickup Date : October 16, 2019</p></div>"
            ],
            [
                "Copart- Punta Gorda, FL (33982)",
                "26.961326",
                "-81.986565",
                "<div class=\"info_content\"><h3>Copart- Punta Gorda, FL (33982)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Copart- Dayton, OH (45439)",
                "39.6902494",
                "-84.2211804",
                "<div class=\"info_content\"><h3>Copart- Dayton, OH (45439)</h3><p> Vehicle List : Toyota Sienna 2007</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "IAAI- Rock Tavern, NY (12575)",
                "41.5354129",
                "-74.1337648",
                "<div class=\"info_content\"><h3>IAAI- Rock Tavern, NY (12575)</h3><p> Vehicle List : TOYOTA SIENNA 2005</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "IAAI- Houston, TX (77032)",
                "29.9576277",
                "-95.3848025",
                "<div class=\"info_content\"><h3>IAAI- Houston, TX (77032)</h3><p> Vehicle List : TOYOTA RAV4 2008</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Copart- Jacksonville, FL (32209)",
                "30.361915",
                "-81.714115",
                "<div class=\"info_content\"><h3>Copart- Jacksonville, FL (32209)</h3><p> Vehicle List : Acura TL 2012</p><p> Pickup Date : October 14, 2019</p></div>"
            ],
            [
                "Copart- Wilmer, TX (75172)",
                "32.601648",
                "-96.664759",
                "<div class=\"info_content\"><h3>Copart- Wilmer, TX (75172)</h3><p> Vehicle List : TOYOTA RAV4 2006</p><p> Pickup Date : October 16, 2019</p></div>"
            ],
            [
                "IAAI- Buffalo, NY (14207)",
                "42.9638692",
                "-78.9029184",
                "<div class=\"info_content\"><h3>IAAI- Buffalo, NY (14207)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Best 4 Shipping Inc., NY (11434)",
                "40.6660699",
                "-73.781",
                "<div class=\"info_content\"><h3>Best 4 Shipping Inc., NY (11434)</h3><p> Vehicle List : Mercedes-Benz C240 2003</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Copart- Glassboro, NJ (08028)",
                "39.6966008",
                "-75.1066342",
                "<div class=\"info_content\"><h3>Copart- Glassboro, NJ (08028)</h3><p> Vehicle List : Toyota Sienna 2000</p><p> Pickup Date : October 11, 2019</p></div>"
            ],
            [
                "IAAI-West Dale, TX (78616)",
                "30.0681035",
                "-97.5789122",
                "<div class=\"info_content\"><h3>IAAI-West Dale, TX (78616)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : October 11, 2019</p></div>"
            ],
            [
                "Copart- North Billerica, MA (01862)",
                "42.582396",
                "-71.273231",
                "<div class=\"info_content\"><h3>Copart- North Billerica, MA (01862)</h3><p> Vehicle List : TOYOTA RAV4 2007</p><p> Pickup Date : October 10, 2019</p></div>"
            ],
            [
                "Copart-Dunn, NC (28334)",
                "35.267059",
                "-78.6198821",
                "<div class=\"info_content\"><h3>Copart-Dunn, NC (28334)</h3><p> Vehicle List : HYUNDAI ELANTRA 2012</p><p> Pickup Date : October 11, 2019</p></div>"
            ],
            [
                "Samuel Oladunjoye, NY (10473)",
                "40.811547",
                "-73.859549",
                "<div class=\"info_content\"><h3>Samuel Oladunjoye, NY (10473)</h3><p> Vehicle List : Mercedes-Benz ML 350 2004</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Unique Motor sport, NY (11743)",
                "40.8341642",
                "-73.3387713",
                "<div class=\"info_content\"><h3>Unique Motor sport, NY (11743)</h3><p> Vehicle List : Lexus Lx570 2017</p></div>"
            ],
            [
                "IAAI-Charlotte, NC (28206)",
                "35.2711906",
                "-80.8181847",
                "<div class=\"info_content\"><h3>IAAI-Charlotte, NC (28206)</h3><p> Vehicle List : Mercedes-Benz E-Class 2011</p></div>"
            ],
            [
                "Copart- Bridgeton, MO (63044)",
                "38.7819952",
                "-90.424149",
                "<div class=\"info_content\"><h3>Copart- Bridgeton, MO (63044)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "Kelvin Odita, NY (11434)",
                "40.6812166",
                "-73.7772032",
                "<div class=\"info_content\"><h3>Kelvin Odita, NY (11434)</h3><p> Vehicle List : Toyota 4Runner 2016</p><p> Pickup Date : October 15, 2019</p></div>"
            ],
            [
                "Copart- Lexington, KY (40509)",
                "37.9604699",
                "-84.3727768",
                "<div class=\"info_content\"><h3>Copart- Lexington, KY (40509)</h3><p> Vehicle List : Toyota Rav4 2009</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IAAI-Long Island, NY (11763)",
                "40.8165759",
                "-72.9736454",
                "<div class=\"info_content\"><h3>IAAI-Long Island, NY (11763)</h3><p> Vehicle List : Lexus Rx330 2005</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "IAAI - Ashland, VA (23005)",
                "37.718384",
                "-77.4659521",
                "<div class=\"info_content\"><h3>IAAI - Ashland, VA (23005)</h3><p> Vehicle List : Lexus Rx300 2000</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "Copart- Andrew, TX (79714)",
                "32.3095027",
                "-102.6091753",
                "<div class=\"info_content\"><h3>Copart- Andrew, TX (79714)</h3><p> Vehicle List : Lexus IS250 2007</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IaaI-Blackwood, NJ (08012)",
                "39.7889681",
                "-75.0880913",
                "<div class=\"info_content\"><h3>IaaI-Blackwood, NJ (08012)</h3><p> Vehicle List : Mercedes-Benz GLK 2010</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IAAI- Laurel, MD (20707)",
                "39.0787603",
                "-76.8837171",
                "<div class=\"info_content\"><h3>IAAI- Laurel, MD (20707)</h3><p> Vehicle List : Honda Crv 2008</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "Copart- York Haven, PA (17370)",
                "40.1116976",
                "-76.7853992",
                "<div class=\"info_content\"><h3>Copart- York Haven, PA (17370)</h3><p> Vehicle List : Acura TL 2009</p></div>"
            ],
            [
                "IAAI - Dothan, AL (36345)",
                "31.365132",
                "-85.3279582",
                "<div class=\"info_content\"><h3>IAAI - Dothan, AL (36345)</h3><p> Vehicle List : Toyota Corolla 2016</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IAAI- Carteret, NJ (07008)",
                "40.5835627",
                "-74.2483619",
                "<div class=\"info_content\"><h3>IAAI- Carteret, NJ (07008)</h3><p> Vehicle List : Toyota 4Runner 2015</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "Copart- Ellwood, PA (16117)",
                "40.850717",
                "-80.314047",
                "<div class=\"info_content\"><h3>Copart- Ellwood, PA (16117)</h3><p> Vehicle List : Toyota Venza 2011</p><p> Pickup Date : October 7, 2019</p></div>"
            ],
            [
                "Copart- Houston, TX (77073)",
                "29.9685949",
                "-95.3735982",
                "<div class=\"info_content\"><h3>Copart- Houston, TX (77073)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "On the Road Automotive Group, NY (10466)",
                "40.8860698",
                "-73.8283771",
                "<div class=\"info_content\"><h3>On the Road Automotive Group, NY (10466)</h3><p> Vehicle List : Acura RDX 2013</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "Copart- Spartanburg (Sublot), SC (29301)",
                "34.9246512",
                "-82.0583214",
                "<div class=\"info_content\"><h3>Copart- Spartanburg (Sublot), SC (29301)</h3><p> Vehicle List : Toyota Highlander 2012</p></div>"
            ],
            [
                "Copart- Fort Worth, TX (76052)",
                "32.9454992",
                "-97.3796397",
                "<div class=\"info_content\"><h3>Copart- Fort Worth, TX (76052)</h3><p> Vehicle List : Toyota Venza 2013</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "IAAI- San Antonio, TX (78224)",
                "29.306394",
                "-98.5379893",
                "<div class=\"info_content\"><h3>IAAI- San Antonio, TX (78224)</h3><p> Vehicle List : Mercedes-Benz GLE 2016</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "IAAI- Medford, NY (11763)",
                "40.8165759",
                "-72.9736454",
                "<div class=\"info_content\"><h3>IAAI- Medford, NY (11763)</h3><p> Vehicle List : Toyota Camry 2011</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IAAI- Markham, IL (60428)",
                "41.5906058",
                "-87.7133362",
                "<div class=\"info_content\"><h3>IAAI- Markham, IL (60428)</h3><p> Vehicle List : Toyota Matrix 2009, Toyota Avalon 2008</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "Copart- Hurricane, WV (25526)",
                "38.4139826",
                "-82.0196112",
                "<div class=\"info_content\"><h3>Copart- Hurricane, WV (25526)</h3><p> Vehicle List : TOYOTA COROLLA 2010</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "IAAI- New Castle, DE (19720)",
                "39.697699",
                "-75.6164897",
                "<div class=\"info_content\"><h3>IAAI- New Castle, DE (19720)</h3><p> Vehicle List : Lexus Rx300 1999, Toyota Camry 2010</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "Copart-Walton, KY (41094)",
                "38.8489402",
                "-84.5997719",
                "<div class=\"info_content\"><h3>Copart-Walton, KY (41094)</h3><p> Vehicle List : Lexus Rx300 2003</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "Copart-Blaine Sublot, MN (55434)",
                "45.1623436",
                "-93.2364563",
                "<div class=\"info_content\"><h3>Copart-Blaine Sublot, MN (55434)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : October 9, 2019</p></div>"
            ],
            [
                "Copart-Candia, NH (03034)",
                "43.0606819",
                "-71.2787724",
                "<div class=\"info_content\"><h3>Copart-Candia, NH (03034)</h3><p> Vehicle List : Toyota Rav4 2008</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "Moruff O. Salaudeen, NY (11436)",
                "40.6718171",
                "-73.7977928",
                "<div class=\"info_content\"><h3>Moruff O. Salaudeen, NY (11436)</h3><p> Vehicle List : Toyota Matrix 2005</p><p> Pickup Date : October 2, 2019</p></div>"
            ],
            [
                "IAAI-Wichita, KS (67219)",
                "37.798734",
                "-97.3365226",
                "<div class=\"info_content\"><h3>IAAI-Wichita, KS (67219)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "Copart-Amarillo, TX (79118)",
                "35.172049",
                "-101.740744",
                "<div class=\"info_content\"><h3>Copart-Amarillo, TX (79118)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "IAAI- Cicero, NY (13039)",
                "43.179594",
                "-76.1246239",
                "<div class=\"info_content\"><h3>IAAI- Cicero, NY (13039)</h3><p> Vehicle List : Toyota Camry 2014</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "IAAI- Baltimore, MD (21226)",
                "39.202368",
                "-76.5584543",
                "<div class=\"info_content\"><h3>IAAI- Baltimore, MD (21226)</h3><p> Vehicle List : Nissan Truck King Cab 1994</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "IAAI-Shirley, MA (01464)",
                "42.5876791",
                "-71.6621903",
                "<div class=\"info_content\"><h3>IAAI-Shirley, MA (01464)</h3><p> Vehicle List : BMW X5 2005</p><p> Pickup Date : October 2, 2019</p></div>"
            ],
            [
                "IAAI- Denver, CO (80221)",
                "39.8170704",
                "-104.993076",
                "<div class=\"info_content\"><h3>IAAI- Denver, CO (80221)</h3><p> Vehicle List : Toyota Highlander 2012</p><p> Pickup Date : October 2, 2019</p></div>"
            ],
            [
                "IAAI- Culpeper, VA (22701)",
                "38.4930927",
                "-77.9278674",
                "<div class=\"info_content\"><h3>IAAI- Culpeper, VA (22701)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "Copart-Elgin, IL (60120)",
                "42.0161694",
                "-88.2357297",
                "<div class=\"info_content\"><h3>Copart-Elgin, IL (60120)</h3><p> Vehicle List : Mazda^ Cx-9 2008</p><p> Pickup Date : October 3, 2019</p></div>"
            ],
            [
                "Conrad Olonimoyo, NY (11432)",
                "40.7154518",
                "-73.7919103",
                "<div class=\"info_content\"><h3>Conrad Olonimoyo, NY (11432)</h3><p> Vehicle List : Lexus IS 350 2007</p><p> Pickup Date : October 4, 2019</p></div>"
            ],
            [
                "Copart-Temple, TX (76501)",
                "31.1630759",
                "-97.3190062",
                "<div class=\"info_content\"><h3>Copart-Temple, TX (76501)</h3><p> Vehicle List : Toyota Sienna 2000</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "Leonard Olonimoyo, NY (11428)",
                "40.7226473",
                "-73.7389596",
                "<div class=\"info_content\"><h3>Leonard Olonimoyo, NY (11428)</h3><p> Vehicle List : Toyota Rav4 2016</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "Copart-Long Island, NY (11719)",
                "40.7776791",
                "-72.9309324",
                "<div class=\"info_content\"><h3>Copart-Long Island, NY (11719)</h3><p> Vehicle List : Toyota Matrix 2005</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "IAAI- East Dundee, IL (60118)",
                "42.0906617",
                "-88.2341193",
                "<div class=\"info_content\"><h3>IAAI- East Dundee, IL (60118)</h3><p> Vehicle List : Toyota Highlander 2014</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "IAAI-Orlando, FL (32824)",
                "28.4223249",
                "-81.3781934",
                "<div class=\"info_content\"><h3>IAAI-Orlando, FL (32824)</h3><p> Vehicle List : Lexus Es350 2011</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "IAAI- De Soto, IA (50069)",
                "41.5410701",
                "-94.0195435",
                "<div class=\"info_content\"><h3>IAAI- De Soto, IA (50069)</h3><p> Vehicle List : Mercedes Benz C300 2008</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "Lehigh Valley Auto Auctions LLC, PA (18052)",
                "40.6531646",
                "-75.5014555",
                "<div class=\"info_content\"><h3>Lehigh Valley Auto Auctions LLC, PA (18052)</h3><p> Vehicle List : Toyota Highlander 2006</p></div>"
            ],
            [
                "IAAI- Middletown, CT (06457)",
                "41.5222496",
                "-72.601289",
                "<div class=\"info_content\"><h3>IAAI- Middletown, CT (06457)</h3><p> Vehicle List : Toyota Camry 2012</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "IAAI- Opa Locka, FL (33054)",
                "25.887392",
                "-80.2690676",
                "<div class=\"info_content\"><h3>IAAI- Opa Locka, FL (33054)</h3><p> Vehicle List : Land Rover Range Rover 2003</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "Iaai- Tampa North, FL (34667)",
                "28.3825311",
                "-82.6699466",
                "<div class=\"info_content\"><h3>Iaai- Tampa North, FL (34667)</h3><p> Vehicle List : Honda Accord 2006</p><p> Pickup Date : October 2, 2019</p></div>"
            ],
            [
                "IAAI- Pembroke Pines,Florida, FL (33332)",
                "26.0449099",
                "-80.4223505",
                "<div class=\"info_content\"><h3>IAAI- Pembroke Pines,Florida, FL (33332)</h3><p> Vehicle List : Toyota Corolla 2007, Toyota Corolla 2006</p></div>"
            ],
            [
                "Steve c/o Steven Opara, NY (10705)",
                "40.9180569",
                "-73.8977693",
                "<div class=\"info_content\"><h3>Steve c/o Steven Opara, NY (10705)</h3><p> Vehicle List : Toyota Highlander 2011</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "DCH Toyota City, NY (10473)",
                "40.946614",
                "-73.74539",
                "<div class=\"info_content\"><h3>DCH Toyota City, NY (10473)</h3><p> Vehicle List : Ford Edge 2010</p><p> Pickup Date : September 26, 2019</p></div>"
            ],
            [
                "John Udaze, NY (11764)",
                "40.9389569",
                "-72.9873924",
                "<div class=\"info_content\"><h3>John Udaze, NY (11764)</h3><p> Vehicle List : Toyota Venza 2010</p><p> Pickup Date : September 27, 2019</p></div>"
            ],
            [
                "Adesa- Long Island, NY (11980)",
                "40.8168076",
                "-72.946334",
                "<div class=\"info_content\"><h3>Adesa- Long Island, NY (11980)</h3><p> Vehicle List : Toyota Sienna 1998</p><p> Pickup Date : September 27, 2019</p></div>"
            ],
            [
                "IAAI- Pulaski, VA (24301)",
                "37.044911",
                "-80.75551",
                "<div class=\"info_content\"><h3>IAAI- Pulaski, VA (24301)</h3><p> Vehicle List : Audi A4 2007</p><p> Pickup Date : September 26, 2019</p></div>"
            ],
            [
                "IAAI- Avenel, NJ (07001)",
                "40.5986938",
                "-74.2562185",
                "<div class=\"info_content\"><h3>IAAI- Avenel, NJ (07001)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 26, 2019</p></div>"
            ],
            [
                "East Paterson c/o Peter Ogbole, NJ (07513)",
                "40.9045824",
                "-74.1504204",
                "<div class=\"info_content\"><h3>East Paterson c/o Peter Ogbole, NJ (07513)</h3><p> Vehicle List : Lexus IS250 2008</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "IAAI-Suffolk, VA (23434)",
                "36.7507137",
                "-76.5203977",
                "<div class=\"info_content\"><h3>IAAI-Suffolk, VA (23434)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : October 1, 2019</p></div>"
            ],
            [
                "IAAI- Winder, GA (30680)",
                "33.9756816",
                "-83.6571508",
                "<div class=\"info_content\"><h3>IAAI- Winder, GA (30680)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "Copart- Exeter, RI (02822)",
                "41.5706609",
                "-71.6578976",
                "<div class=\"info_content\"><h3>Copart- Exeter, RI (02822)</h3><p> Vehicle List : Kia Sportage 2006</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "Copart- Newburg, NY (12542)",
                "41.6165753",
                "-73.9617262",
                "<div class=\"info_content\"><h3>Copart- Newburg, NY (12542)</h3><p> Vehicle List : Nissan Pathfinder 2008</p><p> Pickup Date : October 2, 2019</p></div>"
            ],
            [
                "Copart- Wichita, KS (67216)",
                "37.612203",
                "-97.307341",
                "<div class=\"info_content\"><h3>Copart- Wichita, KS (67216)</h3><p> Vehicle List : Toyota Highlander 2013</p><p> Pickup Date : October 8, 2019</p></div>"
            ],
            [
                "IAAI- Schenectady, NY (12303)",
                "42.7407375",
                "-73.8871837",
                "<div class=\"info_content\"><h3>IAAI- Schenectady, NY (12303)</h3><p> Vehicle List : Chevrolet S10 2000</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "IAAI-Salt Lake City, UT (84401)",
                "41.2344034",
                "-112.0069463",
                "<div class=\"info_content\"><h3>IAAI-Salt Lake City, UT (84401)</h3><p> Vehicle List : Jeep Grand Cherokee 2004, Dodge Dakota 2002</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Unprovided, IL (60154)",
                "41.845718",
                "-87.8893383",
                "<div class=\"info_content\"><h3>Unprovided, IL (60154)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Copart- Philadelphia, PA (18914)",
                "40.2919344",
                "-75.1934344",
                "<div class=\"info_content\"><h3>Copart- Philadelphia, PA (18914)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Richard Olonimoyo, NY (11432)",
                "40.7154518",
                "-73.7919103",
                "<div class=\"info_content\"><h3>Richard Olonimoyo, NY (11432)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "C/O Odusanya Abdulsalam, NY (10306)",
                "40.5729336",
                "-74.1298684",
                "<div class=\"info_content\"><h3>C/O Odusanya Abdulsalam, NY (10306)</h3><p> Vehicle List : Lexus Rx300 2002</p></div>"
            ],
            [
                "Copart-Albany, NY (12205)",
                "42.7357541",
                "-73.8549952",
                "<div class=\"info_content\"><h3>Copart-Albany, NY (12205)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "IAAI-Sandston, VA (23150)",
                "37.522367",
                "-77.289745",
                "<div class=\"info_content\"><h3>IAAI-Sandston, VA (23150)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "IAAI-Sanford, FL (32773)",
                "28.7847855",
                "-81.216402",
                "<div class=\"info_content\"><h3>IAAI-Sanford, FL (32773)</h3><p> Vehicle List : Toyota Rav4 2008</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "IAAI - New Orleans, LA (70126)",
                "30.0035645",
                "-90.0106427",
                "<div class=\"info_content\"><h3>IAAI - New Orleans, LA (70126)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Copart- Eight Mile, AL (36613)",
                "30.788402",
                "-88.217824",
                "<div class=\"info_content\"><h3>Copart- Eight Mile, AL (36613)</h3><p> Vehicle List : Toyota Highlander 2011</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "Peter Ogbole c/o Raul, NY (11224)",
                "40.5749261",
                "-73.9859414",
                "<div class=\"info_content\"><h3>Peter Ogbole c/o Raul, NY (11224)</h3><p> Vehicle List : Toyota Rav4 2014</p><p> Pickup Date : September 25, 2019</p></div>"
            ],
            [
                "Copart-West Warren, MA (01092)",
                "42.2183228",
                "-72.2302834",
                "<div class=\"info_content\"><h3>Copart-West Warren, MA (01092)</h3><p> Vehicle List : Toyota Venza 2009</p><p> Pickup Date : September 23, 2019</p></div>"
            ],
            [
                "Max c/o Joe Joseph, PA (15301)",
                "40.1627412",
                "-80.254435",
                "<div class=\"info_content\"><h3>Max c/o Joe Joseph, PA (15301)</h3><p> Vehicle List : Toyota Highlander 2005</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Dickson Omoregie, NY (12206)",
                "42.6757698",
                "-73.7860276",
                "<div class=\"info_content\"><h3>Dickson Omoregie, NY (12206)</h3><p> Vehicle List : Toyota Corolla 2014</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Jones Akinseye, NY (11434)",
                "40.6812166",
                "-73.7772032",
                "<div class=\"info_content\"><h3>Jones Akinseye, NY (11434)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : September 23, 2019</p></div>"
            ],
            [
                "Aviv Ovadia, NY (11229)",
                "40.6552458",
                "-73.945734",
                "<div class=\"info_content\"><h3>Aviv Ovadia, NY (11229)</h3><p> Vehicle List : Mercedes-Benz ML350 2005</p><p> Pickup Date : September 20, 2019</p></div>"
            ],
            [
                "IAAI- Loganville, GA (30052)",
                "33.7249363",
                "-83.912646",
                "<div class=\"info_content\"><h3>IAAI- Loganville, GA (30052)</h3><p> Vehicle List : HYUNDAI SONATA 2012, Toyota Highlander 2006, MERCEDES C240 2002, TOYOTA HIGHLANDER 2001, TOYOTA HIGHLANDER 2001</p><p> Pickup Date : September 23, 2019</p></div>"
            ],
            [
                "Richard Cole, NC (28269)",
                "35.3352529",
                "-80.7990185",
                "<div class=\"info_content\"><h3>Richard Cole, NC (28269)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "IAAI- Bergen, NY (14416)",
                "43.0737006",
                "-77.9411046",
                "<div class=\"info_content\"><h3>IAAI- Bergen, NY (14416)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 24, 2019</p></div>"
            ],
            [
                "Copart- McAllen, TX (78570)",
                "26.161469",
                "-97.894809",
                "<div class=\"info_content\"><h3>Copart- McAllen, TX (78570)</h3><p> Vehicle List : Lexus Rx300 2002</p><p> Pickup Date : September 20, 2019</p></div>"
            ],
            [
                "IaaI-Houston (Mt. Houston Road), TX (77038)",
                "29.8971015",
                "-95.4501502",
                "<div class=\"info_content\"><h3>IaaI-Houston (Mt. Houston Road), TX (77038)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 19, 2019</p></div>"
            ],
            [
                "IAAI- Park City, KS (67204)",
                "37.798734",
                "-97.3365226",
                "<div class=\"info_content\"><h3>IAAI- Park City, KS (67204)</h3><p> Vehicle List : Mercedes-Benz C-class 2010</p><p> Pickup Date : September 19, 2019</p></div>"
            ],
            [
                "IAAI-Bowling Green, KY (42101)",
                "37.0013425",
                "-86.4552097",
                "<div class=\"info_content\"><h3>IAAI-Bowling Green, KY (42101)</h3><p> Vehicle List : Toyota Venza* 2013</p><p> Pickup Date : September 19, 2019</p></div>"
            ],
            [
                "IAAI- Aliquippa, PA (15001)",
                "40.6218393",
                "-80.2415506",
                "<div class=\"info_content\"><h3>IAAI- Aliquippa, PA (15001)</h3><p> Vehicle List : Toyota Rav4 2007</p><p> Pickup Date : September 18, 2019</p></div>"
            ],
            [
                "IAAI-Justin, TX (76247)",
                "33.0545466",
                "-97.2693558",
                "<div class=\"info_content\"><h3>IAAI-Justin, TX (76247)</h3><p> Vehicle List : Toyota Rav4 2008</p><p> Pickup Date : September 19, 2019</p></div>"
            ],
            [
                "Copart- Windsor, NJ (08561)",
                "40.250962",
                "-74.5739849",
                "<div class=\"info_content\"><h3>Copart- Windsor, NJ (08561)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "IAAI- St. Paul, MN (55117)",
                "44.9789741",
                "-93.0955201",
                "<div class=\"info_content\"><h3>IAAI- St. Paul, MN (55117)</h3><p> Vehicle List : Hyundai Sonata 2011</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "IAAI - Grand Prairie, TX (75050)",
                "32.7500269",
                "-96.941533",
                "<div class=\"info_content\"><h3>IAAI - Grand Prairie, TX (75050)</h3><p> Vehicle List : Mercedes-Benz GLK 2011</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "IAAI-Salem, NH (03079)",
                "42.7649958",
                "-71.2451179",
                "<div class=\"info_content\"><h3>IAAI-Salem, NH (03079)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "IAAI- Fredericksburg, VA (22408)",
                "38.2611621",
                "-77.4999011",
                "<div class=\"info_content\"><h3>IAAI- Fredericksburg, VA (22408)</h3><p> Vehicle List : Toyota Highlander 2007</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "Copart- Riverview, FL (33578)",
                "27.8237147",
                "-82.3301746",
                "<div class=\"info_content\"><h3>Copart- Riverview, FL (33578)</h3><p> Vehicle List : Toyota Camry* 2005, Toyota Corolla 2000, Nissan Pathfinder 2008</p></div>"
            ],
            [
                "Joe Joseph 2009 (09 Honda accord), CT (06105)",
                "41.7721061",
                "-72.7038047",
                "<div class=\"info_content\"><h3>Joe Joseph 2009 (09 Honda accord), CT (06105)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : September 18, 2019</p></div>"
            ],
            [
                "Oluwole Oyewo, NY (11691)",
                "40.6024346",
                "-73.762495",
                "<div class=\"info_content\"><h3>Oluwole Oyewo, NY (11691)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "Copart-Lansig, MI (48917)",
                "42.69265",
                "-84.663067",
                "<div class=\"info_content\"><h3>Copart-Lansig, MI (48917)</h3><p> Vehicle List : Toyota Avalon 2007</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "IAAI- Knoxville, TN (37914)",
                "35.974083",
                "-83.821777",
                "<div class=\"info_content\"><h3>IAAI- Knoxville, TN (37914)</h3><p> Vehicle List : Acura ZDX 2012</p><p> Pickup Date : September 13, 2019</p></div>"
            ],
            [
                "Mercedes-Benz of Nashville, TN (37067)",
                "35.9597703",
                "-86.8050598",
                "<div class=\"info_content\"><h3>Mercedes-Benz of Nashville, TN (37067)</h3><p> Vehicle List : Toyota Corolla 2003, Toyota Highlander 2003</p><p> Pickup Date : September 13, 2019</p></div>"
            ],
            [
                "Copart- Grand Prairie, TX (75051)",
                "32.7420851",
                "-96.9526749",
                "<div class=\"info_content\"><h3>Copart- Grand Prairie, TX (75051)</h3><p> Vehicle List : Toyota Camry 2007, Toyota Camry 2007</p><p> Pickup Date : September 13, 2019</p></div>"
            ],
            [
                "Victor Nwankwo, PA (17104)",
                "40.255136",
                "-76.857682",
                "<div class=\"info_content\"><h3>Victor Nwankwo, PA (17104)</h3><p> Vehicle List : Toyota Rav4 2005</p><p> Pickup Date : September 13, 2019</p></div>"
            ],
            [
                "IAAI- Philadelphia, PA (19428)",
                "40.0308843",
                "-75.0222296",
                "<div class=\"info_content\"><h3>IAAI- Philadelphia, PA (19428)</h3><p> Vehicle List : Toyota Sienna 2002</p></div>"
            ],
            [
                "Copart-Miami, FL (33167)",
                "25.881698",
                "-80.258701",
                "<div class=\"info_content\"><h3>Copart-Miami, FL (33167)</h3><p> Vehicle List : Toyota Sienna 2006</p><p> Pickup Date : September 12, 2019</p></div>"
            ],
            [
                "Copart- Miami, FL (33054)",
                "25.8917305",
                "-80.2439733",
                "<div class=\"info_content\"><h3>Copart- Miami, FL (33054)</h3><p> Vehicle List : KIA Sportage 2010</p></div>"
            ],
            [
                "Copart-Lebanon, TN (37090)",
                "36.1686817",
                "-86.2964702",
                "<div class=\"info_content\"><h3>Copart-Lebanon, TN (37090)</h3><p> Vehicle List : Lexus Rx 330 2004</p><p> Pickup Date : September 12, 2019</p></div>"
            ],
            [
                "Copart- Le Roy, NY (14482)",
                "42.9815523",
                "-78.0034966",
                "<div class=\"info_content\"><h3>Copart- Le Roy, NY (14482)</h3><p> Vehicle List : Toyota Highlander 2008</p><p> Pickup Date : September 12, 2019</p></div>"
            ],
            [
                "Copart- Jacksonville West, FL (32220)",
                "30.3178716",
                "-81.7877093",
                "<div class=\"info_content\"><h3>Copart- Jacksonville West, FL (32220)</h3><p> Vehicle List : BMW X5 2011</p><p> Pickup Date : September 11, 2019</p></div>"
            ],
            [
                "Copart- Southern IL, IL (62205)",
                "38.576819",
                "-90.0957237",
                "<div class=\"info_content\"><h3>Copart- Southern IL, IL (62205)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : September 11, 2019</p></div>"
            ],
            [
                "Copart-Ham Lake, MN (55304)",
                "45.2170557",
                "-93.231269",
                "<div class=\"info_content\"><h3>Copart-Ham Lake, MN (55304)</h3><p> Vehicle List : Honda Civic 2003</p><p> Pickup Date : September 11, 2019</p></div>"
            ],
            [
                "IAAI-Manchester offsite, NH (03079)",
                "42.7649958",
                "-71.2451179",
                "<div class=\"info_content\"><h3>IAAI-Manchester offsite, NH (03079)</h3><p> Vehicle List : Honda Accord 2008</p><p> Pickup Date : September 11, 2019</p></div>"
            ],
            [
                "Copart- Chicago Heights, IL (60411)",
                "41.4821045",
                "-87.6303259",
                "<div class=\"info_content\"><h3>Copart- Chicago Heights, IL (60411)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : September 13, 2019</p></div>"
            ],
            [
                "Copart-Adamsburg, PA (15611)",
                "40.3051914",
                "-79.6571309",
                "<div class=\"info_content\"><h3>Copart-Adamsburg, PA (15611)</h3><p> Vehicle List : Honda Pilot 2006</p><p> Pickup Date : September 10, 2019</p></div>"
            ],
            [
                "Copart- Duryea, PA (18642)",
                "41.3378323",
                "-75.7564783",
                "<div class=\"info_content\"><h3>Copart- Duryea, PA (18642)</h3><p> Vehicle List : Jeep Cherokee 2014</p><p> Pickup Date : September 12, 2019</p></div>"
            ],
            [
                "IAAI- Oklahoma city, OK (73121)",
                "35.5451816",
                "-97.4556309",
                "<div class=\"info_content\"><h3>IAAI- Oklahoma city, OK (73121)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : September 10, 2019</p></div>"
            ],
            [
                "Copart-Anthony, TX (79821)",
                "31.974678",
                "-106.587852",
                "<div class=\"info_content\"><h3>Copart-Anthony, TX (79821)</h3><p> Vehicle List : Mercedes-Benz GLK350 2010</p><p> Pickup Date : September 17, 2019</p></div>"
            ],
            [
                "Kemi Batista, NY (10956)",
                "41.1604286",
                "-73.9947563",
                "<div class=\"info_content\"><h3>Kemi Batista, NY (10956)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : September 10, 2019</p></div>"
            ],
            [
                "Copart- Kansas City, KS (66111)",
                "39.0845599",
                "-94.7243654",
                "<div class=\"info_content\"><h3>Copart- Kansas City, KS (66111)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : September 12, 2019</p></div>"
            ],
            [
                "Copart-Denver, CO (80229)",
                "39.8137153",
                "-104.9726919",
                "<div class=\"info_content\"><h3>Copart-Denver, CO (80229)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : September 10, 2019</p></div>"
            ],
            [
                "IAAI- Lake City, GA (30260)",
                "33.601725",
                "-84.3279504",
                "<div class=\"info_content\"><h3>IAAI- Lake City, GA (30260)</h3><p> Vehicle List : Lexus IS350 2006</p><p> Pickup Date : September 11, 2019</p></div>"
            ],
            [
                "Luxury of Queens, Inc, NY (11101)",
                "40.7547178",
                "-73.9224188",
                "<div class=\"info_content\"><h3>Luxury of Queens, Inc, NY (11101)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : September 9, 2019</p></div>"
            ],
            [
                "Copart- Homestead, FL (33032)",
                "25.541488",
                "-80.411802",
                "<div class=\"info_content\"><h3>Copart- Homestead, FL (33032)</h3><p> Vehicle List : Honda Pilot 2006</p><p> Pickup Date : September 9, 2019</p></div>"
            ],
            [
                "Tee c/o Marshall, NJ (07305)",
                "40.7008528",
                "-74.0887576",
                "<div class=\"info_content\"><h3>Tee c/o Marshall, NJ (07305)</h3><p> Vehicle List : Infiniti Qx56 2011</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "Francis Yusuf Elmont P/U, NY (11003)",
                "40.7006866",
                "-73.706594",
                "<div class=\"info_content\"><h3>Francis Yusuf Elmont P/U, NY (11003)</h3><p> Vehicle List : Lexus Es330 2005</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "Oluwole Oyewo Brentwood P/U, NY (11717)",
                "40.7754622",
                "-73.2411506",
                "<div class=\"info_content\"><h3>Oluwole Oyewo Brentwood P/U, NY (11717)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "Louis c/o Peter Ogbole, NY (11423)",
                "40.7170073",
                "-73.7683784",
                "<div class=\"info_content\"><h3>Louis c/o Peter Ogbole, NY (11423)</h3><p> Vehicle List : Honda Pilot 2003</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "Copart- China Grove, NC (28023)",
                "35.5773628",
                "-80.5597076",
                "<div class=\"info_content\"><h3>Copart- China Grove, NC (28023)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "IAAI- Clearwater, FL (33760)",
                "27.8859296",
                "-82.7038985",
                "<div class=\"info_content\"><h3>IAAI- Clearwater, FL (33760)</h3><p> Vehicle List : Lexus Es330 2005</p><p> Pickup Date : September 10, 2019</p></div>"
            ],
            [
                "Copart- Pekin, IL (61554)",
                "40.5291777",
                "-89.656863",
                "<div class=\"info_content\"><h3>Copart- Pekin, IL (61554)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "IAAI- Belleville (offsite), MI (48111)",
                "42.1716127",
                "-83.5413034",
                "<div class=\"info_content\"><h3>IAAI- Belleville (offsite), MI (48111)</h3><p> Vehicle List : Lexus Es300 2002</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "IAAI- Livingston, LA (70754)",
                "30.4766301",
                "-90.7507823",
                "<div class=\"info_content\"><h3>IAAI- Livingston, LA (70754)</h3><p> Vehicle List : Honda Accord 2009</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "IAAI- Concord, NC (28025)",
                "35.46551",
                "-80.4934214",
                "<div class=\"info_content\"><h3>IAAI- Concord, NC (28025)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "IAAI- Abilene, TX (79601)",
                "32.5382315",
                "-99.7676923",
                "<div class=\"info_content\"><h3>IAAI- Abilene, TX (79601)</h3><p> Vehicle List : Lexus Rx330 2003</p><p> Pickup Date : September 4, 2019</p></div>"
            ],
            [
                "IAAI-Corpus Christi, TX (78405)",
                "27.7854456",
                "-97.4486423",
                "<div class=\"info_content\"><h3>IAAI-Corpus Christi, TX (78405)</h3><p> Vehicle List : Toyota Corolla 2014</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "Copart- Finksburg, MD (21048)",
                "39.5196299",
                "-76.9182048",
                "<div class=\"info_content\"><h3>Copart- Finksburg, MD (21048)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : September 4, 2019</p></div>"
            ],
            [
                "Copart- Central Square, NY (13036)",
                "43.2454283",
                "-76.1458525",
                "<div class=\"info_content\"><h3>Copart- Central Square, NY (13036)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : September 5, 2019</p></div>"
            ],
            [
                "IAAI- East Taunton, MA (02718)",
                "41.8497474",
                "-70.992712",
                "<div class=\"info_content\"><h3>IAAI- East Taunton, MA (02718)</h3><p> Vehicle List : Toyota Corolla 2013</p><p> Pickup Date : September 4, 2019</p></div>"
            ],
            [
                "IAAI- Lexington, SC (29073)",
                "33.9671856",
                "-81.1926718",
                "<div class=\"info_content\"><h3>IAAI- Lexington, SC (29073)</h3><p> Vehicle List : Toyota Avalon 2014</p></div>"
            ],
            [
                "IAAI-Morganville, NJ (07751)",
                "40.3752008",
                "-74.2705895",
                "<div class=\"info_content\"><h3>IAAI-Morganville, NJ (07751)</h3><p> Vehicle List : Toyota Sienna 2005</p><p> Pickup Date : September 4, 2019</p></div>"
            ],
            [
                "Copart-Birmingham, AL (35023)",
                "33.437414",
                "-86.9667657",
                "<div class=\"info_content\"><h3>Copart-Birmingham, AL (35023)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : September 3, 2019</p></div>"
            ],
            [
                "IAAI- DC, Maryland, DC (20613)",
                "38.694842",
                "-76.8470055",
                "<div class=\"info_content\"><h3>IAAI- DC, Maryland, DC (20613)</h3><p> Vehicle List : TOYOTA SIENNA 2005, NISSAN ALTIMA 2008, TOYOTA AVALON 2006, TOYOTA SIENNA 1998</p><p> Pickup Date : September 6, 2019</p></div>"
            ],
            [
                "Major world, NY (11101)",
                "40.75306",
                "-73.9183502",
                "<div class=\"info_content\"><h3>Major world, NY (11101)</h3><p> Vehicle List : Toyota Highlander 2008</p><p> Pickup Date : August 30, 2019</p></div>"
            ],
            [
                "Copart- Indianapolis, IN (46254)",
                "39.8296976",
                "-86.2467957",
                "<div class=\"info_content\"><h3>Copart- Indianapolis, IN (46254)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : August 30, 2019</p></div>"
            ],
            [
                "Copart- Mebane, NC (27302)",
                "36.0962601",
                "-79.3262518",
                "<div class=\"info_content\"><h3>Copart- Mebane, NC (27302)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "One and Only motors, GA (30340)",
                "33.898415",
                "-84.246304",
                "<div class=\"info_content\"><h3>One and Only motors, GA (30340)</h3><p> Vehicle List : Pontiac Vibe 2009</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "Copart- New Orleans, LA (70129)",
                "30.032866",
                "-89.909641",
                "<div class=\"info_content\"><h3>Copart- New Orleans, LA (70129)</h3><p> Vehicle List : Mazda CX9 2007</p><p> Pickup Date : August 30, 2019</p></div>"
            ],
            [
                "Copart-Little Rock, AR (72032)",
                "35.0827028",
                "-92.2890958",
                "<div class=\"info_content\"><h3>Copart-Little Rock, AR (72032)</h3><p> Vehicle List : Toyota Highlander 2003</p><p> Pickup Date : September 3, 2019</p></div>"
            ],
            [
                "IAAI- Anaheim, CA, CA (92806)",
                "33.8608402",
                "-117.8671316",
                "<div class=\"info_content\"><h3>IAAI- Anaheim, CA, CA (92806)</h3><p> Vehicle List : TOYOTA HIGHLANDER 2003</p><p> Pickup Date : August 30, 2019</p></div>"
            ],
            [
                "Copart- Ocala, FL (34482)",
                "29.2612197",
                "-82.195571",
                "<div class=\"info_content\"><h3>Copart- Ocala, FL (34482)</h3><p> Vehicle List : LEXUS ES 330 2004</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "Copart-Lyman, ME (04002)",
                "43.4879713",
                "-70.6313114",
                "<div class=\"info_content\"><h3>Copart-Lyman, ME (04002)</h3><p> Vehicle List : TOYOTA HIGHLANDER 2001</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "IAAI- Columbia, SC (29209)",
                "33.9531398",
                "-80.9558557",
                "<div class=\"info_content\"><h3>IAAI- Columbia, SC (29209)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "Copart- Harrisburg, PA (17028)",
                "40.4131611",
                "-76.6276066",
                "<div class=\"info_content\"><h3>Copart- Harrisburg, PA (17028)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : August 27, 2019</p></div>"
            ],
            [
                "IAAI- York Spring, PA (17372)",
                "40.020352",
                "-77.095252",
                "<div class=\"info_content\"><h3>IAAI- York Spring, PA (17372)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : August 28, 2019</p></div>"
            ],
            [
                "IAAI- Fredericksburg (Leway), VA (22406)",
                "38.353076",
                "-77.5139733",
                "<div class=\"info_content\"><h3>IAAI- Fredericksburg (Leway), VA (22406)</h3><p> Vehicle List : Toyota Tacoma 2006</p><p> Pickup Date : August 28, 2019</p></div>"
            ],
            [
                "Copart- West Palm Beach, FL (33411)",
                "26.6908182",
                "-80.1727533",
                "<div class=\"info_content\"><h3>Copart- West Palm Beach, FL (33411)</h3><p> Vehicle List : Honda Civic 2006</p><p> Pickup Date : August 27, 2019</p></div>"
            ],
            [
                "IAAI-Yorktown, VA (23693)",
                "37.1118834",
                "-76.4639454",
                "<div class=\"info_content\"><h3>IAAI-Yorktown, VA (23693)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : August 27, 2019</p></div>"
            ],
            [
                "Anthony Oloyede, NY (11510)",
                "40.6260153",
                "-73.6006342",
                "<div class=\"info_content\"><h3>Anthony Oloyede, NY (11510)</h3><p> Vehicle List : Toyota Corolla 2012</p><p> Pickup Date : August 27, 2019</p></div>"
            ],
            [
                "Copart- Pennsburg, PA (18073)",
                "40.399774",
                "-75.471594",
                "<div class=\"info_content\"><h3>Copart- Pennsburg, PA (18073)</h3><p> Vehicle List : Lexus Rx330 2005</p><p> Pickup Date : August 30, 2019</p></div>"
            ],
            [
                "Copart Finksburg (Patapsco Sub lot ), MD (21225)",
                "39.2387978",
                "-76.6233412",
                "<div class=\"info_content\"><h3>Copart Finksburg (Patapsco Sub lot ), MD (21225)</h3><p> Vehicle List : Toyota Matrix 2008, Ford Escape 2008</p><p> Pickup Date : August 26, 2019</p></div>"
            ],
            [
                "Insurance Auto auctions, NC (27520)",
                "35.5909529",
                "-78.3987513",
                "<div class=\"info_content\"><h3>Insurance Auto auctions, NC (27520)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : August 26, 2019</p></div>"
            ],
            [
                "IAAI-Springfield, NE (68059)",
                "41.0977675",
                "-96.1454082",
                "<div class=\"info_content\"><h3>IAAI-Springfield, NE (68059)</h3><p> Vehicle List : Toyota Highlander 2001, Toyota Corolla 2003, Acura TL 2005</p><p> Pickup Date : August 27, 2019</p></div>"
            ],
            [
                "IAAI- Indianapolis, IN (46217)",
                "39.7160387",
                "-86.1919872",
                "<div class=\"info_content\"><h3>IAAI- Indianapolis, IN (46217)</h3><p> Vehicle List : Toyota Camry 2010</p><p> Pickup Date : August 23, 2019</p></div>"
            ],
            [
                "Usenekong Attang, NY (11212)",
                "40.6639181",
                "-73.9154069",
                "<div class=\"info_content\"><h3>Usenekong Attang, NY (11212)</h3><p> Vehicle List : Honda Odyssey 2007, Toyota Sienna 2004</p><p> Pickup Date : August 26, 2019</p></div>"
            ],
            [
                "IAAI-Fremont, CA (94538)",
                "37.506244",
                "-121.9921721",
                "<div class=\"info_content\"><h3>IAAI-Fremont, CA (94538)</h3><p> Vehicle List : Lexus Es 2011</p><p> Pickup Date : August 29, 2019</p></div>"
            ],
            [
                "IAAI- Bay Point, CA (94565)",
                "38.0321428",
                "-121.9466235",
                "<div class=\"info_content\"><h3>IAAI- Bay Point, CA (94565)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : August 23, 2019</p></div>"
            ],
            [
                "IAAI-Rosharon, TX (77583)",
                "29.3526033",
                "-95.404404",
                "<div class=\"info_content\"><h3>IAAI-Rosharon, TX (77583)</h3><p> Vehicle List : Honda Civic 2005</p><p> Pickup Date : August 28, 2019</p></div>"
            ],
            [
                "IAAI- Palmetoo, FL (34221)",
                "27.529575",
                "-82.551596",
                "<div class=\"info_content\"><h3>IAAI- Palmetoo, FL (34221)</h3><p> Vehicle List : Toyota Sienna 2006</p><p> Pickup Date : August 22, 2019</p></div>"
            ],
            [
                "IAAI- New Philadelphia, OH (44663)",
                "40.4519584",
                "-81.4039599",
                "<div class=\"info_content\"><h3>IAAI- New Philadelphia, OH (44663)</h3><p> Vehicle List : TOYOTA COROLLA 2009</p><p> Pickup Date : August 28, 2019</p></div>"
            ],
            [
                "Copart- Greenwell Springs, LA (70739)",
                "30.560054",
                "-90.988209",
                "<div class=\"info_content\"><h3>Copart- Greenwell Springs, LA (70739)</h3><p> Vehicle List : Toyota Rav4 2016</p></div>"
            ],
            [
                "Copart-Wheeling, IL (60090)",
                "42.1111952",
                "-87.9136448",
                "<div class=\"info_content\"><h3>Copart-Wheeling, IL (60090)</h3><p> Vehicle List : Toyota Corolla 2012, Toyota Camry 2010</p><p> Pickup Date : August 22, 2019</p></div>"
            ],
            [
                "Kenny Onyide, NY (11510)",
                "40.6260153",
                "-73.6006342",
                "<div class=\"info_content\"><h3>Kenny Onyide, NY (11510)</h3><p> Vehicle List : Lexus Rx350 2010</p><p> Pickup Date : August 21, 2019</p></div>"
            ],
            [
                "Copart- Somerville, NJ (08844)",
                "40.537023",
                "-74.605205",
                "<div class=\"info_content\"><h3>Copart- Somerville, NJ (08844)</h3><p> Vehicle List : Nissan Altima 1998</p></div>"
            ],
            [
                "Autospace collision & glass, NY (11726)",
                "40.681014",
                "-73.391749",
                "<div class=\"info_content\"><h3>Autospace collision & glass, NY (11726)</h3><p> Vehicle List : Lexus Rx330 2004</p><p> Pickup Date : August 22, 2019</p></div>"
            ],
            [
                "Copart-Las Vegas, NV (89115)",
                "36.248051",
                "-115.0790497",
                "<div class=\"info_content\"><h3>Copart-Las Vegas, NV (89115)</h3><p> Vehicle List : Toyota Highlander 2005</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "IAAI-Grenada, MS (38901)",
                "33.6352227",
                "-89.7969098",
                "<div class=\"info_content\"><h3>IAAI-Grenada, MS (38901)</h3><p> Vehicle List : Volkswagen Rabbit 2007</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "Copart- Richmond, VA (23150)",
                "37.522367",
                "-77.289745",
                "<div class=\"info_content\"><h3>Copart- Richmond, VA (23150)</h3><p> Vehicle List : Volkswagen Rabbit 2007</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "IAAI-Rochester, NY (14606)",
                "43.1724809",
                "-77.6855579",
                "<div class=\"info_content\"><h3>IAAI-Rochester, NY (14606)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : August 21, 2019</p></div>"
            ],
            [
                "Copart- Braunfels, TX (78130)",
                "29.7920326",
                "-98.0269112",
                "<div class=\"info_content\"><h3>Copart- Braunfels, TX (78130)</h3><p> Vehicle List : Honda Accord 2006</p><p> Pickup Date : August 19, 2019</p></div>"
            ],
            [
                "IAAI-Bridgeport, PA (19405)",
                "40.1011533",
                "-75.3275799",
                "<div class=\"info_content\"><h3>IAAI-Bridgeport, PA (19405)</h3><p> Vehicle List : Nissan Rogue 2008</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "Copart-Tifton, GA (31794)",
                "31.405896",
                "-83.487653",
                "<div class=\"info_content\"><h3>Copart-Tifton, GA (31794)</h3><p> Vehicle List : Toyota Sienna 2005</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "IAAI-Candia, NH (03034)",
                "43.0606819",
                "-71.2787724",
                "<div class=\"info_content\"><h3>IAAI-Candia, NH (03034)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "Copart- Columbia, MO, MO (65201)",
                "38.949938",
                "-92.209934",
                "<div class=\"info_content\"><h3>Copart- Columbia, MO, MO (65201)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : August 19, 2019</p></div>"
            ],
            [
                "IAAI- El Paso, TX (79927)",
                "31.657795",
                "-106.2364167",
                "<div class=\"info_content\"><h3>IAAI- El Paso, TX (79927)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : August 20, 2019</p></div>"
            ],
            [
                "Copart- Waldorf, MD (20602)",
                "38.5893255",
                "-76.9322445",
                "<div class=\"info_content\"><h3>Copart- Waldorf, MD (20602)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Copart- Florence, MS (39073)",
                "32.1854061",
                "-90.1322649",
                "<div class=\"info_content\"><h3>Copart- Florence, MS (39073)</h3><p> Vehicle List : Toyota Rav4 2016</p><p> Pickup Date : August 18, 2019</p></div>"
            ],
            [
                "IAAI-Doswell, VA (23047)",
                "37.718384",
                "-77.4659521",
                "<div class=\"info_content\"><h3>IAAI-Doswell, VA (23047)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Chris Bekee, NJ (07111)",
                "40.716493",
                "-74.2355404",
                "<div class=\"info_content\"><h3>Chris Bekee, NJ (07111)</h3><p> Vehicle List : Toyota Venza 2009</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "IAAI- Ravenel, SC (29470)",
                "32.844358",
                "-80.237329",
                "<div class=\"info_content\"><h3>IAAI- Ravenel, SC (29470)</h3><p> Vehicle List : Mercedes-Benz ML350 2013</p></div>"
            ],
            [
                "IAAI- Simpsonville, SC (29681)",
                "34.7983781",
                "-82.221801",
                "<div class=\"info_content\"><h3>IAAI- Simpsonville, SC (29681)</h3><p> Vehicle List : Lexus Rx350 2010</p><p> Pickup Date : August 19, 2019</p></div>"
            ],
            [
                "IAAI- Kansas City, KS (66111)",
                "39.0530016",
                "-94.7816841",
                "<div class=\"info_content\"><h3>IAAI- Kansas City, KS (66111)</h3><p> Vehicle List : Nissan Altima 2008</p></div>"
            ],
            [
                "Copart - Royal Purple Sub lot, TX (77523)",
                "29.7831666",
                "-94.8792225",
                "<div class=\"info_content\"><h3>Copart - Royal Purple Sub lot, TX (77523)</h3><p> Vehicle List : Toyota Tacoma 2002</p><p> Pickup Date : August 17, 2019</p></div>"
            ],
            [
                "Makanju Adedapo, NY (11590)",
                "40.7452159",
                "-73.5711912",
                "<div class=\"info_content\"><h3>Makanju Adedapo, NY (11590)</h3><p> Vehicle List : Hyundai Elantra 2017</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Copart- Madisonville, TN (37354)",
                "35.4561321",
                "-84.4359848",
                "<div class=\"info_content\"><h3>Copart- Madisonville, TN (37354)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Hyman Bros Automobiles, VA (23113)",
                "37.5029063",
                "-77.617824",
                "<div class=\"info_content\"><h3>Hyman Bros Automobiles, VA (23113)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : August 15, 2019</p></div>"
            ],
            [
                "IAAI - Granite City, IL (62040)",
                "38.7254814",
                "-90.0580219",
                "<div class=\"info_content\"><h3>IAAI - Granite City, IL (62040)</h3><p> Vehicle List : Dodge Charger 2012</p><p> Pickup Date : August 15, 2019</p></div>"
            ],
            [
                "IAAI-Roseville, MN (55113)",
                "44.9789741",
                "-93.0955201",
                "<div class=\"info_content\"><h3>IAAI-Roseville, MN (55113)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Copart- Columbus, OH (43207)",
                "39.891502",
                "-82.9470053",
                "<div class=\"info_content\"><h3>Copart- Columbus, OH (43207)</h3><p> Vehicle List : Toyota Highlander 2002</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Iaai-Templeton (Offsite), MA (01468)",
                "42.571783",
                "-72.071485",
                "<div class=\"info_content\"><h3>Iaai-Templeton (Offsite), MA (01468)</h3><p> Vehicle List : Toyota Highlander 2006</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Bay Ridge Toyota, NY (11220)",
                "40.6352327",
                "-74.0157559",
                "<div class=\"info_content\"><h3>Bay Ridge Toyota, NY (11220)</h3><p> Vehicle List : Toyota Sienna 2006, Toyota Matrix 2003</p><p> Pickup Date : August 15, 2019</p></div>"
            ],
            [
                "IAAI- Dundalk, MD (21222)",
                "39.2712976",
                "-76.4609054",
                "<div class=\"info_content\"><h3>IAAI- Dundalk, MD (21222)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Greenwood automotive, CO (80112)",
                "39.596389",
                "-104.897869",
                "<div class=\"info_content\"><h3>Greenwood automotive, CO (80112)</h3><p> Vehicle List : Toyota Sienna 2008</p><p> Pickup Date : August 15, 2019</p></div>"
            ],
            [
                "Manny's Auto Sales, NJ (08037)",
                "39.713498",
                "-74.8542191",
                "<div class=\"info_content\"><h3>Manny's Auto Sales, NJ (08037)</h3><p> Vehicle List : Toyota Scion 2005</p><p> Pickup Date : August 14, 2019</p></div>"
            ],
            [
                "IAAI- Greenwood, LA (71033)",
                "32.4474636",
                "-93.9751312",
                "<div class=\"info_content\"><h3>IAAI- Greenwood, LA (71033)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : August 14, 2019</p></div>"
            ],
            [
                "Chris (Via Kamson Shonde), NY (11434)",
                "40.6812166",
                "-73.7772032",
                "<div class=\"info_content\"><h3>Chris (Via Kamson Shonde), NY (11434)</h3><p> Vehicle List : Toyota Camry 2005, Toyota 4runner 2005</p><p> Pickup Date : August 13, 2019</p></div>"
            ],
            [
                "IAAI- Graham, NC (27253)",
                "36.007421",
                "-79.387514",
                "<div class=\"info_content\"><h3>IAAI- Graham, NC (27253)</h3><p> Vehicle List : Honda Accord 2017</p><p> Pickup Date : August 13, 2019</p></div>"
            ],
            [
                "IAAI- Windsor, CT (06088)",
                "41.9213739",
                "-72.6024451",
                "<div class=\"info_content\"><h3>IAAI- Windsor, CT (06088)</h3><p> Vehicle List : Honda Pilot 2008, Toyota Matrix 2005</p><p> Pickup Date : August 14, 2019</p></div>"
            ],
            [
                "IAAI-Providence, RI (02915)",
                "41.8000021",
                "-71.3488967",
                "<div class=\"info_content\"><h3>IAAI-Providence, RI (02915)</h3><p> Vehicle List : Mercedes-Benz E-Class 2012, Nissan Sentra 2008</p></div>"
            ],
            [
                "IAAI- Noho3, CA (91505)",
                "34.1615135",
                "-118.3403506",
                "<div class=\"info_content\"><h3>IAAI- Noho3, CA (91505)</h3><p> Vehicle List : Scion XB 2010</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "Copart - Danville, VA (24531)",
                "36.770902",
                "-79.389997",
                "<div class=\"info_content\"><h3>Copart - Danville, VA (24531)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Copart- Mendon, MA (01756)",
                "42.089724",
                "-71.49853",
                "<div class=\"info_content\"><h3>Copart- Mendon, MA (01756)</h3><p> Vehicle List : Hyundai Elantra 2011</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "Class Auto, NJ (07522)",
                "40.9225965",
                "-74.1784215",
                "<div class=\"info_content\"><h3>Class Auto, NJ (07522)</h3><p> Vehicle List : Toyota Venza 2010</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "Copart Orono Sublot, ME (04473)",
                "44.8876677",
                "-68.7033484",
                "<div class=\"info_content\"><h3>Copart Orono Sublot, ME (04473)</h3><p> Vehicle List : Acura TL 2004</p><p> Pickup Date : August 12, 2019</p></div>"
            ],
            [
                "IAAI- Tucson, AZ (85714)",
                "32.1622706",
                "-110.8931787",
                "<div class=\"info_content\"><h3>IAAI- Tucson, AZ (85714)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "IAAI - San Diego, CA (92154)",
                "32.5560887",
                "-116.9805052",
                "<div class=\"info_content\"><h3>IAAI - San Diego, CA (92154)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : August 16, 2019</p></div>"
            ],
            [
                "Copart- Ellenwood, GA (30294)",
                "33.6255205",
                "-84.2459788",
                "<div class=\"info_content\"><h3>Copart- Ellenwood, GA (30294)</h3><p> Vehicle List : Toyota Highlander 2007</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "Northeast auto transport, VT (05860)",
                "44.819028",
                "-72.221015",
                "<div class=\"info_content\"><h3>Northeast auto transport, VT (05860)</h3><p> Vehicle List : Volvo Xc90 2004</p><p> Pickup Date : August 8, 2019</p></div>"
            ],
            [
                "Copart- Woodhaven, MI (48183)",
                "42.121269",
                "-83.235964",
                "<div class=\"info_content\"><h3>Copart- Woodhaven, MI (48183)</h3><p> Vehicle List : Lexus Rx300 1999</p><p> Pickup Date : August 8, 2019</p></div>"
            ],
            [
                "Ron Motors, NJ (07461)",
                "41.1905004",
                "-74.6420108",
                "<div class=\"info_content\"><h3>Ron Motors, NJ (07461)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : August 8, 2019</p></div>"
            ],
            [
                "Copart- West Mifflin, PA, PA (15122)",
                "40.367094",
                "-79.893883",
                "<div class=\"info_content\"><h3>Copart- West Mifflin, PA, PA (15122)</h3><p> Vehicle List : Honda Accord 2008</p><p> Pickup Date : August 7, 2019</p></div>"
            ],
            [
                "IAAI- Milton, FL, FL (32583)",
                "30.6757027",
                "-86.8496792",
                "<div class=\"info_content\"><h3>IAAI- Milton, FL, FL (32583)</h3><p> Vehicle List : Toyota Camry 2002, Toyota Highlander 2008</p><p> Pickup Date : August 9, 2019</p></div>"
            ],
            [
                "Copart- Tallahassee, FL (32343)",
                "30.4996674",
                "-84.4075213",
                "<div class=\"info_content\"><h3>Copart- Tallahassee, FL (32343)</h3><p> Vehicle List : Toyota Scion 2009</p><p> Pickup Date : August 7, 2019</p></div>"
            ],
            [
                "Palm beach auto sales outlet, FL (33409)",
                "26.698885",
                "-80.110142",
                "<div class=\"info_content\"><h3>Palm beach auto sales outlet, FL (33409)</h3><p> Vehicle List : Toyota Sienna 2004</p><p> Pickup Date : August 7, 2019</p></div>"
            ],
            [
                "Buy & Sell Cars, NY (11373)",
                "40.7388794",
                "-73.8867407",
                "<div class=\"info_content\"><h3>Buy & Sell Cars, NY (11373)</h3><p> Vehicle List : Toyota Camry 2002</p></div>"
            ],
            [
                "Copart- Cartersville, GA (30120)",
                "34.1176439",
                "-84.8932182",
                "<div class=\"info_content\"><h3>Copart- Cartersville, GA (30120)</h3><p> Vehicle List : Lexus Es350 2007</p><p> Pickup Date : August 6, 2019</p></div>"
            ],
            [
                "Copart-Greenville, KY (42345)",
                "37.2273011",
                "-87.2678328",
                "<div class=\"info_content\"><h3>Copart-Greenville, KY (42345)</h3><p> Vehicle List : Mercedes ML350 2006</p><p> Pickup Date : August 7, 2019</p></div>"
            ],
            [
                "Gravity auto sales, GA (30341)",
                "33.8963854",
                "-84.3032659",
                "<div class=\"info_content\"><h3>Gravity auto sales, GA (30341)</h3><p> Vehicle List : Toyota 4runner 2005</p><p> Pickup Date : August 6, 2019</p></div>"
            ],
            [
                "Copart-Harleyville, SC (29448)",
                "33.1995426",
                "-80.4507371",
                "<div class=\"info_content\"><h3>Copart-Harleyville, SC (29448)</h3><p> Vehicle List : Lexus Gx460 2016</p><p> Pickup Date : August 6, 2019</p></div>"
            ],
            [
                "Omonowo Momoh, IN (46818)",
                "41.1614273",
                "-85.2101269",
                "<div class=\"info_content\"><h3>Omonowo Momoh, IN (46818)</h3><p> Vehicle List : Lexus Es350 2007</p><p> Pickup Date : August 6, 2019</p></div>"
            ],
            [
                "Neptune Auto Enterprises, NY (11223)",
                "40.5997956",
                "-73.9616172",
                "<div class=\"info_content\"><h3>Neptune Auto Enterprises, NY (11223)</h3><p> Vehicle List : Toyota Highlander 2008</p><p> Pickup Date : August 7, 2019</p></div>"
            ],
            [
                "Copart- Columbia, SC (29053)",
                "33.864815",
                "-81.086234",
                "<div class=\"info_content\"><h3>Copart- Columbia, SC (29053)</h3><p> Vehicle List : </p></div>"
            ],
            [
                "Copart- Farr West, UT (84404)",
                "41.3216788",
                "-112.0296203",
                "<div class=\"info_content\"><h3>Copart- Farr West, UT (84404)</h3><p> Vehicle List : Toyota Sienna 2009</p><p> Pickup Date : August 5, 2019</p></div>"
            ],
            [
                "Copart-Altoona, PA (15931)",
                "40.4592345",
                "-78.7704076",
                "<div class=\"info_content\"><h3>Copart-Altoona, PA (15931)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : August 6, 2019</p></div>"
            ],
            [
                "Copart- Austell, GA (30168)",
                "33.7987997",
                "-84.62829",
                "<div class=\"info_content\"><h3>Copart- Austell, GA (30168)</h3><p> Vehicle List : Toyota Sienna 2007</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Copart- Rochester, NY (14482)",
                "42.9815523",
                "-78.0034966",
                "<div class=\"info_content\"><h3>Copart- Rochester, NY (14482)</h3><p> Vehicle List : Toyota Camry 2006</p><p> Pickup Date : August 5, 2019</p></div>"
            ],
            [
                "Michael Nwokolo, IN (46835)",
                "41.1448223",
                "-85.0545197",
                "<div class=\"info_content\"><h3>Michael Nwokolo, IN (46835)</h3><p> Vehicle List : Toyota Camry 2010</p><p> Pickup Date : August 4, 2019</p></div>"
            ],
            [
                "Chukwuemeka Nwana, NY (11791)",
                "40.8334827",
                "-73.5005111",
                "<div class=\"info_content\"><h3>Chukwuemeka Nwana, NY (11791)</h3><p> Vehicle List : Toyota Sienna 2000</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Francis Adenuga, NY (11411)",
                "40.6930067",
                "-73.7389596",
                "<div class=\"info_content\"><h3>Francis Adenuga, NY (11411)</h3><p> Vehicle List : Toyota Highlander 2003</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Copart- Memphis, TN (38118)",
                "35.0009304",
                "-89.9727408",
                "<div class=\"info_content\"><h3>Copart- Memphis, TN (38118)</h3><p> Vehicle List : Mercedes-Benz S550 2016</p><p> Pickup Date : August 5, 2019</p></div>"
            ],
            [
                "Yemi (Somerset), NJ (08873)",
                "40.497604",
                "-74.4884868",
                "<div class=\"info_content\"><h3>Yemi (Somerset), NJ (08873)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : August 1, 2019</p></div>"
            ],
            [
                "Copart- Lincoln, NE (68366)",
                "40.975529",
                "-96.390577",
                "<div class=\"info_content\"><h3>Copart- Lincoln, NE (68366)</h3><p> Vehicle List : Toyota Highlander 2005</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Scott Donahue, NY (13790)",
                "42.1883307",
                "-76.0043731",
                "<div class=\"info_content\"><h3>Scott Donahue, NY (13790)</h3><p> Vehicle List : Acura TL 2009, Toyota Sienna 2008</p><p> Pickup Date : August 1, 2019</p></div>"
            ],
            [
                "Blasius Preowned auto sales, CT (06708)",
                "41.5659878",
                "-73.0595611",
                "<div class=\"info_content\"><h3>Blasius Preowned auto sales, CT (06708)</h3><p> Vehicle List : Lexus Rx350 2013, Toyota 4Runner 2011</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Edgar A. Bohrer, WV (25413)",
                "39.324803",
                "-78.007615",
                "<div class=\"info_content\"><h3>Edgar A. Bohrer, WV (25413)</h3><p> Vehicle List : Lexus Es 350 2009</p><p> Pickup Date : August 1, 2019</p></div>"
            ],
            [
                "IAAI- Essex Junction, VT (05452)",
                "44.526644",
                "-73.1294759",
                "<div class=\"info_content\"><h3>IAAI- Essex Junction, VT (05452)</h3><p> Vehicle List : Toyota Rav4 2006</p><p> Pickup Date : July 31, 2019</p></div>"
            ],
            [
                "Andrew Afolabi, NY (11413)",
                "40.6679426",
                "-73.7536695",
                "<div class=\"info_content\"><h3>Andrew Afolabi, NY (11413)</h3><p> Vehicle List : Volkswagen Jetta 2016</p><p> Pickup Date : August 2, 2019</p></div>"
            ],
            [
                "Copart- Apopka, FL (32712)",
                "28.6976638",
                "-81.5674734",
                "<div class=\"info_content\"><h3>Copart- Apopka, FL (32712)</h3><p> Vehicle List : Mercedes-Benz ML350 2013</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Copart- Berlin (Sublot), CT (06037)",
                "41.6504863",
                "-72.7505585",
                "<div class=\"info_content\"><h3>Copart- Berlin (Sublot), CT (06037)</h3><p> Vehicle List : Toyota Highlander 2011</p><p> Pickup Date : July 31, 2019</p></div>"
            ],
            [
                "Knauz Continental Autos, IL (60044)",
                "42.2784394",
                "-87.869511",
                "<div class=\"info_content\"><h3>Knauz Continental Autos, IL (60044)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : August 1, 2019</p></div>"
            ],
            [
                "Copart- Greer, SC (29651)",
                "34.9246512",
                "-82.0583214",
                "<div class=\"info_content\"><h3>Copart- Greer, SC (29651)</h3><p> Vehicle List : Toyota Rav4 2007</p><p> Pickup Date : July 29, 2019</p></div>"
            ],
            [
                "Copart-Hayward, CA (94545)",
                "37.6573377",
                "-122.1357216",
                "<div class=\"info_content\"><h3>Copart-Hayward, CA (94545)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "IAAI- Henderson, NV (89011)",
                "36.0551822",
                "-115.0014489",
                "<div class=\"info_content\"><h3>IAAI- Henderson, NV (89011)</h3><p> Vehicle List : Lexus Es330 2005</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Gladys Aikhionbare, NJ (07112)",
                "40.7132136",
                "-74.2120629",
                "<div class=\"info_content\"><h3>Gladys Aikhionbare, NJ (07112)</h3><p> Vehicle List : Lexus Es300 2002</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Copart- Ft. Pierce, FL (34946)",
                "27.4811243",
                "-80.3790965",
                "<div class=\"info_content\"><h3>Copart- Ft. Pierce, FL (34946)</h3><p> Vehicle List : Toyota Camry 2017</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Copart-Orlando, FL (32824)",
                "28.438024",
                "-81.369408",
                "<div class=\"info_content\"><h3>Copart-Orlando, FL (32824)</h3><p> Vehicle List : Toyota Highlander 2004</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Kelvin Ogelle (pleasantville), NY (10570)",
                "40.6782282",
                "-73.8715166",
                "<div class=\"info_content\"><h3>Kelvin Ogelle (pleasantville), NY (10570)</h3><p> Vehicle List : Honda Element 2004</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "IAAI- Tulsa, OK (74107)",
                "36.0979619",
                "-96.0514183",
                "<div class=\"info_content\"><h3>IAAI- Tulsa, OK (74107)</h3><p> Vehicle List : Lexus Rx330 2005</p><p> Pickup Date : July 26, 2019</p></div>"
            ],
            [
                "Copart Sublot, MD (21162)",
                "39.4037869",
                "-76.3955948",
                "<div class=\"info_content\"><h3>Copart Sublot, MD (21162)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 26, 2019</p></div>"
            ],
            [
                "IAAI- Westchester, OH (45069)",
                "39.3021126",
                "-84.4365888",
                "<div class=\"info_content\"><h3>IAAI- Westchester, OH (45069)</h3><p> Vehicle List : Nissan Pathfinder 2005</p></div>"
            ],
            [
                "Deluxe Auto sales (Charles Baskin), NJ (07036)",
                "40.6310727",
                "-74.2404005",
                "<div class=\"info_content\"><h3>Deluxe Auto sales (Charles Baskin), NJ (07036)</h3><p> Vehicle List : Toyota Camry 2006</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "IAAI- Lafayette, LA (70507)",
                "30.2899738",
                "-92.0566637",
                "<div class=\"info_content\"><h3>IAAI- Lafayette, LA (70507)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : July 26, 2019</p></div>"
            ],
            [
                "L.C whiford Equipment Co, FL (33837)",
                "42.1252012",
                "-77.9748081",
                "<div class=\"info_content\"><h3>L.C whiford Equipment Co, FL (33837)</h3><p> Vehicle List : Toyota Sienna 2004</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Copart- Phoenix, AZ (85043)",
                "33.4417358",
                "-112.1687162",
                "<div class=\"info_content\"><h3>Copart- Phoenix, AZ (85043)</h3><p> Vehicle List : Toyota Camry 2006</p><p> Pickup Date : July 26, 2019</p></div>"
            ],
            [
                "IAAI-Macon, GA (31217)",
                "32.848037",
                "-83.584819",
                "<div class=\"info_content\"><h3>IAAI-Macon, GA (31217)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Copart-Gainesville, GA (30507)",
                "34.2805713",
                "-83.7936697",
                "<div class=\"info_content\"><h3>Copart-Gainesville, GA (30507)</h3><p> Vehicle List : Toyota Camry 2010</p></div>"
            ],
            [
                "Victory Mistubishi, NY (10475)",
                "40.885343",
                "-73.828786",
                "<div class=\"info_content\"><h3>Victory Mistubishi, NY (10475)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Copart- Long beach, CA (90744)",
                "33.7991411",
                "-118.2563163",
                "<div class=\"info_content\"><h3>Copart- Long beach, CA (90744)</h3><p> Vehicle List : Honda Pilot 2006</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "IAAI- Fargo, ND (58102)",
                "46.9391041",
                "-96.8394833",
                "<div class=\"info_content\"><h3>IAAI- Fargo, ND (58102)</h3><p> Vehicle List : Toyota Sienna 2004</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "65 Family auto repair (papa), NY (10456)",
                "40.8485594",
                "-73.8681778",
                "<div class=\"info_content\"><h3>65 Family auto repair (papa), NY (10456)</h3><p> Vehicle List : Toyota Camry 2001</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "Akinsanmi Akindeko, IN (46804)",
                "41.0521864",
                "-85.2411958",
                "<div class=\"info_content\"><h3>Akinsanmi Akindeko, IN (46804)</h3><p> Vehicle List : Mercedes-Benz C-Class 2015</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Copart- Hartford City, IN (47348)",
                "40.4491497",
                "-85.3583099",
                "<div class=\"info_content\"><h3>Copart- Hartford City, IN (47348)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Comfort Olorunsaiye, PA (19001)",
                "40.1313817",
                "-75.1370254",
                "<div class=\"info_content\"><h3>Comfort Olorunsaiye, PA (19001)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "Copart-Davenport, IA (52748)",
                "41.6237772",
                "-90.5799261",
                "<div class=\"info_content\"><h3>Copart-Davenport, IA (52748)</h3><p> Vehicle List : Mercedes-Benz ML 2008</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "IAAI- Cordova, CA (95742)",
                "38.5598383",
                "-121.2528884",
                "<div class=\"info_content\"><h3>IAAI- Cordova, CA (95742)</h3><p> Vehicle List : Toyota Camry 2005</p></div>"
            ],
            [
                "Felix, NJ (07108)",
                "40.7214161",
                "-74.1994518",
                "<div class=\"info_content\"><h3>Felix, NJ (07108)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "IAAI-Hollywood, CA (91605)",
                "34.2030488",
                "-118.3977468",
                "<div class=\"info_content\"><h3>IAAI-Hollywood, CA (91605)</h3><p> Vehicle List : Toyota Corolla 2007</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "Copart-Seaford, DE (19973)",
                "38.630262",
                "-75.562889",
                "<div class=\"info_content\"><h3>Copart-Seaford, DE (19973)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : July 23, 2019</p></div>"
            ],
            [
                "IAAI-Nashville, TN (37218)",
                "36.1964922",
                "-86.8608533",
                "<div class=\"info_content\"><h3>IAAI-Nashville, TN (37218)</h3><p> Vehicle List : Honda Accord 2009, Toyota Tundra 2010</p><p> Pickup Date : July 23, 2019</p></div>"
            ],
            [
                "Copart- Savannah, GA (31405)",
                "32.040761",
                "-81.212716",
                "<div class=\"info_content\"><h3>Copart- Savannah, GA (31405)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : July 23, 2019</p></div>"
            ],
            [
                "Economy Auto Inc, NJ (08879)",
                "40.4961064",
                "-74.2963557",
                "<div class=\"info_content\"><h3>Economy Auto Inc, NJ (08879)</h3><p> Vehicle List : Lexus GX470 2005</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Shola Sowemimo, NY (11091)",
                "40.7127753",
                "-74.0059728",
                "<div class=\"info_content\"><h3>Shola Sowemimo, NY (11091)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 23, 2019</p></div>"
            ],
            [
                "Copart- Portland, MI (48875)",
                "42.8651014",
                "-85.0794346",
                "<div class=\"info_content\"><h3>Copart- Portland, MI (48875)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "Copart- Longview, TX (75603)",
                "32.3734197",
                "-94.7202958",
                "<div class=\"info_content\"><h3>Copart- Longview, TX (75603)</h3><p> Vehicle List : Audi A6 2005</p></div>"
            ],
            [
                "IAAI-Erie, PA (16416)",
                "41.8178238",
                "-79.4506281",
                "<div class=\"info_content\"><h3>IAAI-Erie, PA (16416)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "Copart- Chambersburg, PA (17201)",
                "39.9251028",
                "-77.7334307",
                "<div class=\"info_content\"><h3>Copart- Chambersburg, PA (17201)</h3><p> Vehicle List : Toyota Rav4 2003</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "RBM of Alpharetta, GA (30004)",
                "34.1355496",
                "-84.2405248",
                "<div class=\"info_content\"><h3>RBM of Alpharetta, GA (30004)</h3><p> Vehicle List : Toyota Sienna 2002</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "IAAI- Acworth, GA (30101)",
                "34.0796329",
                "-84.7303597",
                "<div class=\"info_content\"><h3>IAAI- Acworth, GA (30101)</h3><p> Vehicle List : Toyota Rav4 2010</p><p> Pickup Date : July 25, 2019</p></div>"
            ],
            [
                "Bolaji Sogo, WV (26374)",
                "39.4478162",
                "-79.8856824",
                "<div class=\"info_content\"><h3>Bolaji Sogo, WV (26374)</h3><p> Vehicle List : Honda Pilot 2006</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "IAAI- Englishtown, NJ (07726)",
                "40.3752008",
                "-74.2705895",
                "<div class=\"info_content\"><h3>IAAI- Englishtown, NJ (07726)</h3><p> Vehicle List : Toyota Rav4 2013</p><p> Pickup Date : July 22, 2019</p></div>"
            ],
            [
                "IAAI-Rincon, GA (31326)",
                "32.2490243",
                "-81.1984171",
                "<div class=\"info_content\"><h3>IAAI-Rincon, GA (31326)</h3><p> Vehicle List : Lexus Rx300 2001</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "Copart- Brighton, CO (80603)",
                "40.019191",
                "-104.811342",
                "<div class=\"info_content\"><h3>Copart- Brighton, CO (80603)</h3><p> Vehicle List : Toyota Camry 2006</p><p> Pickup Date : July 18, 2019</p></div>"
            ],
            [
                "David, TX (76052)",
                "32.9843533",
                "-97.3840729",
                "<div class=\"info_content\"><h3>David, TX (76052)</h3><p> Vehicle List : Toyota Solara 2004</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "IAAI- Gotham, ME (04038)",
                "43.6648005",
                "-70.4604255",
                "<div class=\"info_content\"><h3>IAAI- Gotham, ME (04038)</h3><p> Vehicle List : Honda Accord 2008</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "Express Auto Credit, NY (13760)",
                "42.1085147",
                "-76.0119222",
                "<div class=\"info_content\"><h3>Express Auto Credit, NY (13760)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "Chain Auto Group, NJ (07801)",
                "40.9073734",
                "-74.5723932",
                "<div class=\"info_content\"><h3>Chain Auto Group, NJ (07801)</h3><p> Vehicle List : Toyota Highlander 2006</p><p> Pickup Date : July 18, 2019</p></div>"
            ],
            [
                "IAAI- Commerce City, CO (80022)",
                "39.8502641",
                "-104.9160262",
                "<div class=\"info_content\"><h3>IAAI- Commerce City, CO (80022)</h3><p> Vehicle List : Toyota Rav4 2014</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "Kayode, TX (75034)",
                "33.1376528",
                "-96.8565427",
                "<div class=\"info_content\"><h3>Kayode, TX (75034)</h3><p> Vehicle List : Toyota Highlander 2014</p></div>"
            ],
            [
                "Copart-Gaston, SC (29053)",
                "33.864815",
                "-81.086234",
                "<div class=\"info_content\"><h3>Copart-Gaston, SC (29053)</h3><p> Vehicle List : Toyota Venza 2010</p><p> Pickup Date : July 24, 2019</p></div>"
            ],
            [
                "Muri Jeje, NY (11691)",
                "40.6024346",
                "-73.762495",
                "<div class=\"info_content\"><h3>Muri Jeje, NY (11691)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "Juan, NY (11717)",
                "40.7472636",
                "-73.2640505",
                "<div class=\"info_content\"><h3>Juan, NY (11717)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 18, 2019</p></div>"
            ],
            [
                "Copart- Rowley, MA (01969)",
                "42.7288504",
                "-70.868951",
                "<div class=\"info_content\"><h3>Copart- Rowley, MA (01969)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : July 23, 2019</p></div>"
            ],
            [
                "Leitrim, CT (06410)",
                "54.1246909",
                "-8.0020132",
                "<div class=\"info_content\"><h3>Leitrim, CT (06410)</h3><p> Vehicle List : Toyota Matrix 2005</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Jeff, PA (17978)",
                "40.6287923",
                "-76.6268306",
                "<div class=\"info_content\"><h3>Jeff, PA (17978)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : July 19, 2019</p></div>"
            ],
            [
                "IAAI- Grove City, OH (43123)",
                "39.8878384",
                "-83.0350724",
                "<div class=\"info_content\"><h3>IAAI- Grove City, OH (43123)</h3><p> Vehicle List : Toyota Sienna 2007, Lexus Rx330 2004</p><p> Pickup Date : July 15, 2019</p></div>"
            ],
            [
                "IAAI- Columbus, OH (43223)",
                "39.8878384",
                "-83.0350724",
                "<div class=\"info_content\"><h3>IAAI- Columbus, OH (43223)</h3><p> Vehicle List : Toyota Rav4 2010</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "Boris Peros, NJ (08816)",
                "40.4333407",
                "-74.4115246",
                "<div class=\"info_content\"><h3>Boris Peros, NJ (08816)</h3><p> Vehicle List : Lexus Rx300 1999</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "David Bavone, CT (06712)",
                "41.4997207",
                "-72.9814877",
                "<div class=\"info_content\"><h3>David Bavone, CT (06712)</h3><p> Vehicle List : Toyota Highlander 2005</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Churchhill Onukwe, NY (12601)",
                "41.7165144",
                "-73.9242251",
                "<div class=\"info_content\"><h3>Churchhill Onukwe, NY (12601)</h3><p> Vehicle List : Toyota Corolla 2007</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Auto Holding, NJ (07205)",
                "40.698179",
                "-74.245307",
                "<div class=\"info_content\"><h3>Auto Holding, NJ (07205)</h3><p> Vehicle List : Lexus Rx330 2004</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Rasaki Shittu, NY (11208)",
                "40.6749343",
                "-73.8713099",
                "<div class=\"info_content\"><h3>Rasaki Shittu, NY (11208)</h3><p> Vehicle List : Toyota Sienna 2006</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Copart- Sun Valley, CA (91352)",
                "34.223501",
                "-118.3802531",
                "<div class=\"info_content\"><h3>Copart- Sun Valley, CA (91352)</h3><p> Vehicle List : Lexus ES300 2005</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "IAAI- Puyallup, WA (98374)",
                "47.1131071",
                "-122.2818557",
                "<div class=\"info_content\"><h3>IAAI- Puyallup, WA (98374)</h3><p> Vehicle List : Toyota Sienna 2007</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Axis Group, NJ (07305)",
                "40.7028184",
                "-74.0759774",
                "<div class=\"info_content\"><h3>Axis Group, NJ (07305)</h3><p> Vehicle List : Toyota Highlander 2006</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Copart Vertia St. Sub lot, GA (30439)",
                "32.3954677",
                "-82.0583211",
                "<div class=\"info_content\"><h3>Copart Vertia St. Sub lot, GA (30439)</h3><p> Vehicle List : Lexus Es330 2005</p><p> Pickup Date : July 17, 2019</p></div>"
            ],
            [
                "High Rated Auto Company Inc., MD (21009)",
                "39.4597185",
                "-76.2556153",
                "<div class=\"info_content\"><h3>High Rated Auto Company Inc., MD (21009)</h3><p> Vehicle List : Lexus Rx300 1999</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Copart- Oklahoma City, OK, OK (73129)",
                "35.450627",
                "-97.4610796",
                "<div class=\"info_content\"><h3>Copart- Oklahoma City, OK, OK (73129)</h3><p> Vehicle List : Toyota Camry 2004</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Adejoh, NJ (07018)",
                "40.7564795",
                "-74.2208673",
                "<div class=\"info_content\"><h3>Adejoh, NJ (07018)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "IAAI- Flint, MI (48507)",
                "42.984319",
                "-83.7832604",
                "<div class=\"info_content\"><h3>IAAI- Flint, MI (48507)</h3><p> Vehicle List : Toyota Rav4 2007</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "IAAI-Byron Center, MI (49315)",
                "42.7821452",
                "-85.6811072",
                "<div class=\"info_content\"><h3>IAAI-Byron Center, MI (49315)</h3><p> Vehicle List : Toyota Matrix 2009</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "Olusola Osunsan, TX (78233)",
                "29.560052",
                "-98.3636131",
                "<div class=\"info_content\"><h3>Olusola Osunsan, TX (78233)</h3><p> Vehicle List : Toyota Corolla 2007</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Copart- Fridley, MN (55421)",
                "45.0386442",
                "-93.2748981",
                "<div class=\"info_content\"><h3>Copart- Fridley, MN (55421)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "Adeniyi Abayomi, GA (30096)",
                "33.9812131",
                "-84.1540659",
                "<div class=\"info_content\"><h3>Adeniyi Abayomi, GA (30096)</h3><p> Vehicle List : Toyota Rav4 2007</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "Bluesky Auto, NJ (08833)",
                "40.6335567",
                "-74.7832114",
                "<div class=\"info_content\"><h3>Bluesky Auto, NJ (08833)</h3><p> Vehicle List : Toyota Corolla 2006</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "IAAI- Portage, WI (53901)",
                "43.5613962",
                "-89.5148856",
                "<div class=\"info_content\"><h3>IAAI- Portage, WI (53901)</h3><p> Vehicle List : Toyota Rav4 2008</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "Akinsanmi Akindeko 2, IN (46835)",
                "41.1448223",
                "-85.0545197",
                "<div class=\"info_content\"><h3>Akinsanmi Akindeko 2, IN (46835)</h3><p> Vehicle List : Toyota Highlander 2002</p></div>"
            ],
            [
                "Florida Auto Imports, FL (33312)",
                "26.0688642",
                "-80.1849758",
                "<div class=\"info_content\"><h3>Florida Auto Imports, FL (33312)</h3><p> Vehicle List : Lexus RX330 2004</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "IAAI- ALBUQUERQUE, NM (87105)",
                "35.0142948",
                "-106.6477809",
                "<div class=\"info_content\"><h3>IAAI- ALBUQUERQUE, NM (87105)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Copart-Avon, MN (56310)",
                "45.6040607",
                "-94.4360873",
                "<div class=\"info_content\"><h3>Copart-Avon, MN (56310)</h3><p> Vehicle List : Toyota Camry 2000</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "IAAI- Lincoln, IL (62656)",
                "40.1538507",
                "-89.408722",
                "<div class=\"info_content\"><h3>IAAI- Lincoln, IL (62656)</h3><p> Vehicle List : Toyota Sienna 2008, Toyota Sienna 2004</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "Ryan, NY (11096)",
                "40.6184845",
                "-73.7536695",
                "<div class=\"info_content\"><h3>Ryan, NY (11096)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "IAAI- Springfield, MO (65803)",
                "37.221748",
                "-93.359855",
                "<div class=\"info_content\"><h3>IAAI- Springfield, MO (65803)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "Chaya Brothers Auto & Salvage LLC, NH (03865)",
                "42.8556192",
                "-71.1099834",
                "<div class=\"info_content\"><h3>Chaya Brothers Auto & Salvage LLC, NH (03865)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "Queen Campbell, NY (11236)",
                "40.6387196",
                "-73.8948295",
                "<div class=\"info_content\"><h3>Queen Campbell, NY (11236)</h3><p> Vehicle List : Toyota Camry 2009</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Yemi, NJ (07055)",
                "40.8597746",
                "-74.1298684",
                "<div class=\"info_content\"><h3>Yemi, NJ (07055)</h3><p> Vehicle List : Scion XA 2005</p><p> Pickup Date : July 11, 2019</p></div>"
            ],
            [
                "IAAI- Fort Myers, FL (33903)",
                "26.667786",
                "-81.9130563",
                "<div class=\"info_content\"><h3>IAAI- Fort Myers, FL (33903)</h3><p> Vehicle List : Mercedes-Benz C300 2008</p><p> Pickup Date : July 12, 2019</p></div>"
            ],
            [
                "Paul Underwood, NY (11550)",
                "40.6986257",
                "-73.6241855",
                "<div class=\"info_content\"><h3>Paul Underwood, NY (11550)</h3><p> Vehicle List : Lexus LS 2010</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Sussex Auto Group, NJ (07849)",
                "40.9573969",
                "-74.6014057",
                "<div class=\"info_content\"><h3>Sussex Auto Group, NJ (07849)</h3><p> Vehicle List : Hyundai Sonata 2013</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "IAAI- Moss point, MS (39562)",
                "30.418206",
                "-88.469644",
                "<div class=\"info_content\"><h3>IAAI- Moss point, MS (39562)</h3><p> Vehicle List : Lexus Es330 2004</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Henry, NY (10952)",
                "41.1091091",
                "-74.0828839",
                "<div class=\"info_content\"><h3>Henry, NY (10952)</h3><p> Vehicle List : Toyota Highlander 2002</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Emmanuel Omoregie, NY (10466)",
                "40.8887394",
                "-73.8477874",
                "<div class=\"info_content\"><h3>Emmanuel Omoregie, NY (10466)</h3><p> Vehicle List : Lexus Es300 2002</p><p> Pickup Date : July 10, 2019</p></div>"
            ],
            [
                "IAAI- Long Island (offsite) Rice Courtyard, NY (11763)",
                "40.8165759",
                "-72.9736454",
                "<div class=\"info_content\"><h3>IAAI- Long Island (offsite) Rice Courtyard, NY (11763)</h3><p> Vehicle List : Toyota Camry 2013</p><p> Pickup Date : July 8, 2019</p></div>"
            ],
            [
                "Wolfchase Toyota, TN (38016)",
                "35.1860916",
                "-89.7941935",
                "<div class=\"info_content\"><h3>Wolfchase Toyota, TN (38016)</h3><p> Vehicle List : Toyota Camry 2004</p><p> Pickup Date : July 8, 2019</p></div>"
            ],
            [
                "Pat (via Janet Fashakin), NY (13658)",
                "40.695157",
                "-73.8412504",
                "<div class=\"info_content\"><h3>Pat (via Janet Fashakin), NY (13658)</h3><p> Vehicle List : Honda Accord 2013</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Janet Fashakin, NY (11568)",
                "40.695157",
                "-73.8412504",
                "<div class=\"info_content\"><h3>Janet Fashakin, NY (11568)</h3><p> Vehicle List : Hyundai Sonata 2014</p><p> Pickup Date : July 9, 2019</p></div>"
            ],
            [
                "Copart- Littleton, CO (80125)",
                "39.5582203",
                "-105.0423143",
                "<div class=\"info_content\"><h3>Copart- Littleton, CO (80125)</h3><p> Vehicle List : BMW X5 2005</p></div>"
            ],
            [
                "Copart- Loganville, GA (30052)",
                "33.8043662",
                "-83.955099",
                "<div class=\"info_content\"><h3>Copart- Loganville, GA (30052)</h3><p> Vehicle List : Toyota Corolla 2004</p><p> Pickup Date : July 8, 2019</p></div>"
            ],
            [
                "IAAI- Spokane Valley, WA (99216)",
                "47.6894133",
                "-117.1668827",
                "<div class=\"info_content\"><h3>IAAI- Spokane Valley, WA (99216)</h3><p> Vehicle List : Toyota Rav4 2004</p><p> Pickup Date : July 4, 2019</p></div>"
            ],
            [
                "Manheim-San francisco Bay, CA (94544)",
                "37.6152848",
                "-122.0689088",
                "<div class=\"info_content\"><h3>Manheim-San francisco Bay, CA (94544)</h3><p> Vehicle List : Toyota Corolla 2014, Toyota Camry 2008</p><p> Pickup Date : July 16, 2019</p></div>"
            ],
            [
                "Mercedes of White plains Overflow, NY (10523)",
                "41.0289331",
                "-73.7739579",
                "<div class=\"info_content\"><h3>Mercedes of White plains Overflow, NY (10523)</h3><p> Vehicle List : Mercedes-Benz E350 2016</p><p> Pickup Date : July 2, 2019</p></div>"
            ],
            [
                "Copart- San Antonio, TX (78224)",
                "29.3083423",
                "-98.5472942",
                "<div class=\"info_content\"><h3>Copart- San Antonio, TX (78224)</h3><p> Vehicle List : Toyota Rav4 2006</p><p> Pickup Date : July 2, 2019</p></div>"
            ],
            [
                "Patricia B. Rodger, NY (11412)",
                "40.6963978",
                "-73.762495",
                "<div class=\"info_content\"><h3>Patricia B. Rodger, NY (11412)</h3><p> Vehicle List : Toyota Camry 2003, Nissan Sentra 2007</p></div>"
            ],
            [
                "IAAI- Chattanooga, TN (37404)",
                "35.0174699",
                "-85.2998068",
                "<div class=\"info_content\"><h3>IAAI- Chattanooga, TN (37404)</h3><p> Vehicle List : Toyota Camry 2002</p><p> Pickup Date : July 1, 2019</p></div>"
            ],
            [
                "Manheim- Fairfield, NJ (07004)",
                "40.8672578",
                "-74.3069851",
                "<div class=\"info_content\"><h3>Manheim- Fairfield, NJ (07004)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : June 28, 2019</p></div>"
            ],
            [
                "IAAI- Pensacola Offsite, FL (32433)",
                "30.6757027",
                "-86.8496792",
                "<div class=\"info_content\"><h3>IAAI- Pensacola Offsite, FL (32433)</h3><p> Vehicle List : Pontiac Vibe 2004</p><p> Pickup Date : July 1, 2019</p></div>"
            ],
            [
                "Copart- Los Angeles, CA (90001)",
                "33.9619345",
                "-118.2319909",
                "<div class=\"info_content\"><h3>Copart- Los Angeles, CA (90001)</h3><p> Vehicle List : Mercedes-Benz C-Class 2005</p><p> Pickup Date : July 2, 2019</p></div>"
            ],
            [
                "IaaI-Byram, MS (39272)",
                "32.1601526",
                "-90.2774619",
                "<div class=\"info_content\"><h3>IaaI-Byram, MS (39272)</h3><p> Vehicle List : Toyota Camry 2005</p></div>"
            ],
            [
                "Manheim- Fort lauderdale, FL (33314)",
                "26.0552357",
                "-80.2101889",
                "<div class=\"info_content\"><h3>Manheim- Fort lauderdale, FL (33314)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : June 27, 2019</p></div>"
            ],
            [
                "Manheim- Bordentown, NJ (08505)",
                "40.1124217",
                "-74.7011554",
                "<div class=\"info_content\"><h3>Manheim- Bordentown, NJ (08505)</h3><p> Vehicle List : Honda Pilot 2004</p><p> Pickup Date : June 28, 2019</p></div>"
            ],
            [
                "Corona's auto parts & towing, CT (06114)",
                "41.7395809",
                "-72.6698912",
                "<div class=\"info_content\"><h3>Corona's auto parts & towing, CT (06114)</h3><p> Vehicle List : Toyota Highlander 2002</p></div>"
            ],
            [
                "IAAI- Normandy (Offsite), FL (32221)",
                "30.2690132",
                "-81.8437134",
                "<div class=\"info_content\"><h3>IAAI- Normandy (Offsite), FL (32221)</h3><p> Vehicle List : Toyota Highlander 2015</p><p> Pickup Date : June 27, 2019</p></div>"
            ],
            [
                "IAAI- Hartford, CT (06088)",
                "41.9213739",
                "-72.6024451",
                "<div class=\"info_content\"><h3>IAAI- Hartford, CT (06088)</h3><p> Vehicle List : Toyota Corolla 2009</p><p> Pickup Date : June 26, 2019</p></div>"
            ],
            [
                "Axis Group Biz LLC, NJ (07306)",
                "40.7028184",
                "-74.0759774",
                "<div class=\"info_content\"><h3>Axis Group Biz LLC, NJ (07306)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : June 27, 2019</p></div>"
            ],
            [
                "Afeez Adebara, OK (73072)",
                "35.2340635",
                "-97.5138947",
                "<div class=\"info_content\"><h3>Afeez Adebara, OK (73072)</h3><p> Vehicle List : Honda Fit 2008, Infiniti G37 2009</p><p> Pickup Date : June 25, 2019</p></div>"
            ],
            [
                "Carlink, NJ (07960)",
                "40.803358",
                "-74.464636",
                "<div class=\"info_content\"><h3>Carlink, NJ (07960)</h3><p> Vehicle List : Toyota Highlander 2001</p><p> Pickup Date : June 26, 2019</p></div>"
            ],
            [
                "Crown Cars, TN (37311)",
                "35.1582607",
                "-84.8838823",
                "<div class=\"info_content\"><h3>Crown Cars, TN (37311)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : July 1, 2019</p></div>"
            ],
            [
                "Lexus Atlanta, GA (30341)",
                "33.9095135",
                "-84.2889346",
                "<div class=\"info_content\"><h3>Lexus Atlanta, GA (30341)</h3><p> Vehicle List : Ford Explorer 2010</p></div>"
            ],
            [
                "Autobahn Volvo, TX (76107)",
                "32.7595507",
                "-97.3593361",
                "<div class=\"info_content\"><h3>Autobahn Volvo, TX (76107)</h3><p> Vehicle List : Volvo s40 2008</p><p> Pickup Date : June 26, 2019</p></div>"
            ],
            [
                "Kelvin Ogelle, NY (12594)",
                "40.6782282",
                "-73.8715166",
                "<div class=\"info_content\"><h3>Kelvin Ogelle, NY (12594)</h3><p> Vehicle List : Hyundai Elantra 2008</p><p> Pickup Date : June 26, 2019</p></div>"
            ],
            [
                "Manheim- Cranberry Township, PA (16066)",
                "40.7304418",
                "-80.1102823",
                "<div class=\"info_content\"><h3>Manheim- Cranberry Township, PA (16066)</h3><p> Vehicle List : Toyota Matrix XR 2006</p><p> Pickup Date : June 25, 2019</p></div>"
            ],
            [
                "Kingsley Mwuonagha, NY (11003)",
                "40.7006866",
                "-73.706594",
                "<div class=\"info_content\"><h3>Kingsley Mwuonagha, NY (11003)</h3><p> Vehicle List : Lexus IS250 2007, Toyota Corolla 2008</p><p> Pickup Date : June 25, 2019</p></div>"
            ],
            [
                "Manheim- Newburgh, NY (12550)",
                "41.5173099",
                "-74.0941676",
                "<div class=\"info_content\"><h3>Manheim- Newburgh, NY (12550)</h3><p> Vehicle List : Acura MDX 2010</p></div>"
            ],
            [
                "Devil's Bowl Raceway, VT (05743)",
                "43.667557",
                "-73.29277",
                "<div class=\"info_content\"><h3>Devil's Bowl Raceway, VT (05743)</h3><p> Vehicle List : Mazda MPV 2006</p><p> Pickup Date : June 24, 2019</p></div>"
            ],
            [
                "Manheim- Fredericksburg, VA (22406)",
                "38.3531795",
                "-77.4947745",
                "<div class=\"info_content\"><h3>Manheim- Fredericksburg, VA (22406)</h3><p> Vehicle List : Toyota Corolla 2010</p><p> Pickup Date : June 26, 2019</p></div>"
            ],
            [
                "Affordable Motor, NY (11224)",
                "40.5803536",
                "-73.9853357",
                "<div class=\"info_content\"><h3>Affordable Motor, NY (11224)</h3><p> Vehicle List : Ford F150 2010</p><p> Pickup Date : June 24, 2019</p></div>"
            ],
            [
                "Michael Gokhfeld, NY (11235)",
                "40.5860069",
                "-73.9418603",
                "<div class=\"info_content\"><h3>Michael Gokhfeld, NY (11235)</h3><p> Vehicle List : Toyota 4Runner 2016</p><p> Pickup Date : June 21, 2019</p></div>"
            ],
            [
                "Emeka Ndichie, NJ (07111)",
                "40.716493",
                "-74.2355404",
                "<div class=\"info_content\"><h3>Emeka Ndichie, NJ (07111)</h3><p> Vehicle List : Lexus Rx350 2010</p></div>"
            ],
            [
                "Luxury Motors, NJ (07202)",
                "40.652658",
                "-74.2155448",
                "<div class=\"info_content\"><h3>Luxury Motors, NJ (07202)</h3><p> Vehicle List : Acura ZDX 2012</p><p> Pickup Date : June 24, 2019</p></div>"
            ],
            [
                "Copart- Van nuys, CA (91405)",
                "34.2073998",
                "-118.4334399",
                "<div class=\"info_content\"><h3>Copart- Van nuys, CA (91405)</h3><p> Vehicle List : Toyota Sienna* 2005</p><p> Pickup Date : June 24, 2019</p></div>"
            ],
            [
                "Fredrik Ahuwa, NC (28215)",
                "35.2413572",
                "-80.7103532",
                "<div class=\"info_content\"><h3>Fredrik Ahuwa, NC (28215)</h3><p> Vehicle List : Honda Pilot 2008</p><p> Pickup Date : June 21, 2019</p></div>"
            ],
            [
                "Adeleke Thomas, NY (11691)",
                "40.6024346",
                "-73.762495",
                "<div class=\"info_content\"><h3>Adeleke Thomas, NY (11691)</h3><p> Vehicle List : Honda Civic 2016</p><p> Pickup Date : June 25, 2019</p></div>"
            ],
            [
                "Kenneth Omatseye, GA (30008)",
                "33.8955185",
                "-84.5903367",
                "<div class=\"info_content\"><h3>Kenneth Omatseye, GA (30008)</h3><p> Vehicle List : Honda Accord 2006</p></div>"
            ],
            [
                "Lonestar Motorcars LLC, TX (75001)",
                "32.9855853",
                "-96.8523276",
                "<div class=\"info_content\"><h3>Lonestar Motorcars LLC, TX (75001)</h3><p> Vehicle List : Toyota Rav4 2010</p><p> Pickup Date : June 21, 2019</p></div>"
            ],
            [
                "Eagle Auto Enterprise, NY (10462)",
                "40.8427048",
                "-73.8548979",
                "<div class=\"info_content\"><h3>Eagle Auto Enterprise, NY (10462)</h3><p> Vehicle List : Toyota Sienna 2004</p><p> Pickup Date : June 20, 2019</p></div>"
            ],
            [
                "Gotcha Auto Inc- Island Park, NY (11558)",
                "40.6052379",
                "-73.6506309",
                "<div class=\"info_content\"><h3>Gotcha Auto Inc- Island Park, NY (11558)</h3><p> Vehicle List : Mercedes Benz ML350 2008</p><p> Pickup Date : June 24, 2019</p></div>"
            ],
            [
                "Kingsley Aifuobhokhan, NY (11412)",
                "40.6963978",
                "-73.762495",
                "<div class=\"info_content\"><h3>Kingsley Aifuobhokhan, NY (11412)</h3><p> Vehicle List : Volkswagen Jetta 2015</p><p> Pickup Date : July 30, 2019</p></div>"
            ],
            [
                "Faulkner Toyota, PA (19053)",
                "40.123199",
                "-74.976207",
                "<div class=\"info_content\"><h3>Faulkner Toyota, PA (19053)</h3><p> Vehicle List : Lexus LX570 2016</p><p> Pickup Date : July 2, 2019</p></div>"
            ],
            [
                "Century Auto Sport, CA (91405)",
                "34.2137235",
                "-118.4656404",
                "<div class=\"info_content\"><h3>Century Auto Sport, CA (91405)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : June 20, 2019</p></div>"
            ],
            [
                "IAAI- Bay City (Offsite), MI (48708)",
                "43.548189",
                "-83.828058",
                "<div class=\"info_content\"><h3>IAAI- Bay City (Offsite), MI (48708)</h3><p> Vehicle List : Toyota Corolla 2006, Mercedes-Benz C230 2005</p><p> Pickup Date : June 20, 2019</p></div>"
            ],
            [
                "Adeola Famojur, NY (10462)",
                "40.8382522",
                "-73.8566087",
                "<div class=\"info_content\"><h3>Adeola Famojur, NY (10462)</h3><p> Vehicle List : Toyota Camry 2012</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "IAAI- Fort Pierce, FL (34945)",
                "27.452567",
                "-80.405417",
                "<div class=\"info_content\"><h3>IAAI- Fort Pierce, FL (34945)</h3><p> Vehicle List : Lexus Rx350 2008</p><p> Pickup Date : June 20, 2019</p></div>"
            ],
            [
                "Godwin Okpome, NY (10469)",
                "40.8690303",
                "-73.8477874",
                "<div class=\"info_content\"><h3>Godwin Okpome, NY (10469)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Efeturi Eregha, NY (11423)",
                "40.7170073",
                "-73.7683784",
                "<div class=\"info_content\"><h3>Efeturi Eregha, NY (11423)</h3><p> Vehicle List : Toyota Corolla 2008</p><p> Pickup Date : June 20, 2019</p></div>"
            ],
            [
                "Edwin, NY (11520)",
                "40.8610213",
                "-73.9258861",
                "<div class=\"info_content\"><h3>Edwin, NY (11520)</h3><p> Vehicle List : Nissan Altima 2007</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Contact not provided, NY (10453)",
                "40.8509205",
                "-73.9081034",
                "<div class=\"info_content\"><h3>Contact not provided, NY (10453)</h3><p> Vehicle List : Honda Accord 2015</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Rasaq Oyinboade, CT (06610)",
                "41.2007682",
                "-73.1644628",
                "<div class=\"info_content\"><h3>Rasaq Oyinboade, CT (06610)</h3><p> Vehicle List : Toyota Camry 2003</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Mama Seun, NY (11003)",
                "40.7006866",
                "-73.706594",
                "<div class=\"info_content\"><h3>Mama Seun, NY (11003)</h3><p> Vehicle List : Toyota Rav4 2014</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Crown Ford, NY (11563)",
                "40.6556534",
                "-73.6657214",
                "<div class=\"info_content\"><h3>Crown Ford, NY (11563)</h3><p> Vehicle List : Toyota Camry 1999</p></div>"
            ],
            [
                "Copart-Rogersville, MO (65742)",
                "37.1197301",
                "-93.0132954",
                "<div class=\"info_content\"><h3>Copart-Rogersville, MO (65742)</h3><p> Vehicle List : Hyundai Santa Fe 2009</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Ram Chrysler Jeep Dodge Ram, NJ (07446)",
                "41.0768456",
                "-74.1483562",
                "<div class=\"info_content\"><h3>Ram Chrysler Jeep Dodge Ram, NJ (07446)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Kamson Shonde, NY (11435)",
                "40.7031635",
                "-73.8095574",
                "<div class=\"info_content\"><h3>Kamson Shonde, NY (11435)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Copart-Hueytown, AL (35023)",
                "33.437414",
                "-86.9667657",
                "<div class=\"info_content\"><h3>Copart-Hueytown, AL (35023)</h3><p> Vehicle List : Lexus Es300 2003</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "IAAI- Davenport, IA (52802)",
                "41.485021",
                "-90.650577",
                "<div class=\"info_content\"><h3>IAAI- Davenport, IA (52802)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Copart-Shreveport, LA (71109)",
                "32.4649759",
                "-93.8379531",
                "<div class=\"info_content\"><h3>Copart-Shreveport, LA (71109)</h3><p> Vehicle List : Land Rover LR4 2010</p><p> Pickup Date : June 19, 2019</p></div>"
            ],
            [
                "Tunde Taiwo, NJ (07405)",
                "40.9886496",
                "-74.3822058",
                "<div class=\"info_content\"><h3>Tunde Taiwo, NJ (07405)</h3><p> Vehicle List : Nissan NV200 2015</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Palisades Auto Sales, NY (10960)",
                "41.0938759",
                "-73.9332955",
                "<div class=\"info_content\"><h3>Palisades Auto Sales, NY (10960)</h3><p> Vehicle List : Nissan NV200 2017</p><p> Pickup Date : June 18, 2019</p></div>"
            ],
            [
                "Copart-Hampton, VA (23666)",
                "37.0705527",
                "-76.3850155",
                "<div class=\"info_content\"><h3>Copart-Hampton, VA (23666)</h3><p> Vehicle List : Honda Civic 2008</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Copart- Flint, MI (48423)",
                "43.078125",
                "-83.518111",
                "<div class=\"info_content\"><h3>Copart- Flint, MI (48423)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Copart- East Cleveland, OH (44067)",
                "41.282507",
                "-81.5049505",
                "<div class=\"info_content\"><h3>Copart- East Cleveland, OH (44067)</h3><p> Vehicle List : Honda Accord 2004, Honda CRV 2007</p><p> Pickup Date : June 17, 2019</p></div>"
            ],
            [
                "Name not provided, GA (30319)",
                "33.8730946",
                "-84.338429",
                "<div class=\"info_content\"><h3>Name not provided, GA (30319)</h3><p> Vehicle List : Honda Element 2004</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Peter Ogbole, NY (11757)",
                "40.6821467",
                "-73.3767641",
                "<div class=\"info_content\"><h3>Peter Ogbole, NY (11757)</h3><p> Vehicle List : Pontiac Vibe 2009</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "IAAI- Shady Spring, WV (25918)",
                "37.7415486",
                "-80.9969345",
                "<div class=\"info_content\"><h3>IAAI- Shady Spring, WV (25918)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Copart-Colorado Springs sublot, CO (80916)",
                "38.886995",
                "-104.815413",
                "<div class=\"info_content\"><h3>Copart-Colorado Springs sublot, CO (80916)</h3><p> Vehicle List : Toyota Corolla 2005</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Copart- Sikeston, MO (63801)",
                "36.938444",
                "-89.531298",
                "<div class=\"info_content\"><h3>Copart- Sikeston, MO (63801)</h3><p> Vehicle List : Toyota Highlander 2002</p></div>"
            ],
            [
                "Adelani Orobiyi, NY (10475)",
                "40.87347",
                "-73.8272029",
                "<div class=\"info_content\"><h3>Adelani Orobiyi, NY (10475)</h3><p> Vehicle List : Lexus* Gx 2016</p><p> Pickup Date : June 14, 2019</p></div>"
            ],
            [
                "Copart- Gray (Sublot), ME (04039)",
                "43.88015",
                "-70.3418779",
                "<div class=\"info_content\"><h3>Copart- Gray (Sublot), ME (04039)</h3><p> Vehicle List : Honda Odyssey* 2006</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "Karp Volvo, NY (11570)",
                "40.656758",
                "-73.639285",
                "<div class=\"info_content\"><h3>Karp Volvo, NY (11570)</h3><p> Vehicle List : Mercedes Benz E-class 2016</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "Copart-Springfield, MO (65742)",
                "37.1197301",
                "-93.0132954",
                "<div class=\"info_content\"><h3>Copart-Springfield, MO (65742)</h3><p> Vehicle List : Toyota Camry 2008</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "Omagbemi Omatsola, NY (11422)",
                "40.6584068",
                "-73.7389596",
                "<div class=\"info_content\"><h3>Omagbemi Omatsola, NY (11422)</h3><p> Vehicle List : Toyota Venza 2012</p><p> Pickup Date : June 25, 2019</p></div>"
            ],
            [
                "Manheim-Philadelphia, PA (19440)",
                "40.295904",
                "-75.2825502",
                "<div class=\"info_content\"><h3>Manheim-Philadelphia, PA (19440)</h3><p> Vehicle List : Toyota Sienna 2000</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "IAAI- Tampa, FL (33619)",
                "27.972894",
                "-82.3971814",
                "<div class=\"info_content\"><h3>IAAI- Tampa, FL (33619)</h3><p> Vehicle List : Toyota Camry 2007</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "Lia Toyota of rockland, NY (10913)",
                "41.0802256",
                "-73.9504337",
                "<div class=\"info_content\"><h3>Lia Toyota of rockland, NY (10913)</h3><p> Vehicle List : Toyota Camry 2002, Ford F150 2008</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "Ayinde Lawal, NY (11423)",
                "40.7170073",
                "-73.7683784",
                "<div class=\"info_content\"><h3>Ayinde Lawal, NY (11423)</h3><p> Vehicle List : Lexus Rx330 2004</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "Copart- Big Lake sublot, MN (55309)",
                "45.220746",
                "-93.261601",
                "<div class=\"info_content\"><h3>Copart- Big Lake sublot, MN (55309)</h3><p> Vehicle List : Lexus Rx350 2011, Mercedes-Benz C240 2003</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "IAAI- Redwing (offsite), MN (55066)",
                "44.5027689",
                "-92.5594214",
                "<div class=\"info_content\"><h3>IAAI- Redwing (offsite), MN (55066)</h3><p> Vehicle List : Volkswagen Routan* 2009</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "Auto Gallery, NJ (07644)",
                "40.8764055",
                "-74.0719553",
                "<div class=\"info_content\"><h3>Auto Gallery, NJ (07644)</h3><p> Vehicle List : Toyota Highlander 2012</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "Manheim- PA, PA (17545)",
                "40.1634279",
                "-76.3949614",
                "<div class=\"info_content\"><h3>Manheim- PA, PA (17545)</h3><p> Vehicle List : Toyota Corolla 2003</p><p> Pickup Date : June 12, 2019</p></div>"
            ],
            [
                "Michael Otugh, NY (11411)",
                "40.6930067",
                "-73.7389596",
                "<div class=\"info_content\"><h3>Michael Otugh, NY (11411)</h3><p> Vehicle List : Toyota Camry 2005</p><p> Pickup Date : June 13, 2019</p></div>"
            ],
            [
                "Adesa, NJ (08835)",
                "40.5491048",
                "-74.5831853",
                "<div class=\"info_content\"><h3>Adesa, NJ (08835)</h3><p> Vehicle List : Mercedes-Benz GLK 350 2013</p><p> Pickup Date : June 11, 2019</p></div>"
            ],
            [
                "Lanre Oluwaseun, NY (11691)",
                "40.6024346",
                "-73.762495",
                "<div class=\"info_content\"><h3>Lanre Oluwaseun, NY (11691)</h3><p> Vehicle List : Land Rover Range Rover 2010</p><p> Pickup Date : June 10, 2019</p></div>"
            ],
            [
                "IAAI- Faribault (Offsite), MN (55021)",
                "44.3724804",
                "-93.2350897",
                "<div class=\"info_content\"><h3>IAAI- Faribault (Offsite), MN (55021)</h3><p> Vehicle List : Honda Pilot 2006</p><p> Pickup Date : June 11, 2019</p></div>"
            ],
            [
                "Kehinde Topman Okunola, NY (11434)",
                "40.6812166",
                "-73.7772032",
                "<div class=\"info_content\"><h3>Kehinde Topman Okunola, NY (11434)</h3><p> Vehicle List : Dodge Caravan 2006</p><p> Pickup Date : June 10, 2019</p></div>"
            ],
            [
                "Mr. Kay, NY (11691)",
                "40.6024346",
                "-73.762495",
                "<div class=\"info_content\"><h3>Mr. Kay, NY (11691)</h3><p> Vehicle List : Toyota Camry 2004, Toyota Corolla 2004, Toyota Sienna 2005</p><p> Pickup Date : June 11, 2019</p></div>"
            ],
            [
                "IAAI-Castle Hayne, NC (28429)",
                "34.3301329",
                "-77.9057289",
                "<div class=\"info_content\"><h3>IAAI-Castle Hayne, NC (28429)</h3><p> Vehicle List : Toyota Corolla 2007</p><p> Pickup Date : June 11, 2019</p></div>"
            ]

        ];